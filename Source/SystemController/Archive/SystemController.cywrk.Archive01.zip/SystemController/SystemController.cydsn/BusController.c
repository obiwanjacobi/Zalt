#include "BusController.h"
#include "CpuController.h"

#define SysCtrlReg_BusEnable    0
#define SysCtrlReg_DataBusEnable    1

void BusController_EnableExternalBus(uint8_t enable)
{
    uint8_t ctrlReg = SysCtrlReg_Read();
    
    if (enable) ctrlReg |= (1 << SysCtrlReg_BusEnable);
    else ctrlReg &= ~(1 << SysCtrlReg_BusEnable);
    
    SysCtrlReg_Write(ctrlReg);
}

inline void BusController_EnableDataBusOutput(uint8_t enable)
{
    uint8_t ctrlReg = SysCtrlReg_Read();
    
    if (enable) ctrlReg |= (1 << SysCtrlReg_DataBusEnable);
    else ctrlReg &= ~(1 << SysCtrlReg_DataBusEnable);
    
    SysCtrlReg_Write(ctrlReg);
}

void BusController_WaitForBusAckOrReset(uint8_t active)
{
    while (CyPins_ReadPin(ExtBus_BusAck) == active)
    {
        if (CpuController_IsResetActive()) return;
    }
}

void BusController_Init()
{
    // disable external bus
    BusController_EnableExternalBus(0);
    BusController_EnableDataBusOutput(0);
    
    // set control lines in neutral state
    CyPins_SetPin(ExtBus_BusReq);
    CyPins_SetPin(ExtBus_MemReq);
    CyPins_SetPin(ExtBus_IoReq);
    CyPins_SetPin(ExtBus_Rd);
    CyPins_SetPin(ExtBus_Wr);
    
    LsbA_Write(0);
    MsbA_Write(0);
    D_Write(0);
}

void BusController_Acquire()
{
    // activate BusReq
    CyPins_ClearPin(ExtBus_BusReq);

    // set control lines in neutral state
    CyPins_SetPin(ExtBus_MemReq);
    CyPins_SetPin(ExtBus_IoReq);
    CyPins_SetPin(ExtBus_Rd);
    CyPins_SetPin(ExtBus_Wr);
    LsbA_Write(0);
    MsbA_Write(0);
    D_Write(0);
    
    // wait for acknowledge
    BusController_WaitForBusAckOrReset(1);
    
    // enable our bus
    BusController_EnableExternalBus(1);
}

void BusController_Release()
{
    // disable output drives on the external bus
    BusController_EnableExternalBus(0);
    BusController_EnableDataBusOutput(0);
    
    // release BusReq
    CyPins_SetPin(ExtBus_BusReq);
    
    // wait for cpu to take over bus again
    BusController_WaitForBusAckOrReset(0);
}

uint8_t BusController_IsAcquired()
{
    uint8_t ctrlReg = SysCtrlReg_Read();
    return (ctrlReg & (1 << SysCtrlReg_BusEnable)) > 0;
}


/* [] END OF FILE */
