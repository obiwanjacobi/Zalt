#ifndef __COMMANDPARSER_H__
#define __COMMANDPARSER_H__

#include <project.h>
#include "RingBuffer.h"

#define COMMAND_NONE            0
#define COMMAND_MEMORYWRITE     1
#define COMMAND_MEMORYREAD      2

#define COMMAND_CLOCKMODE       3
#define COMMAND_CLOCKDIVIDER    4
#define COMMAND_CLOCKPULSE      5
    
#define COMMAND_CPURESET        6
    
typedef struct
{
    uint8_t CommandLine[5];
    
    uint16_t Command;
    union {
        uint16_t Address;
        uint16_t Number;
        uint16_t Mode;
    };
    union {
        uint16_t Length;
    };
    union {
        uint16_t Param3;
    };

} TerminalCommand;

uint8_t CommandParser_BuildCommand(TerminalCommand* command, RingBuffer* buffer);
uint8_t CommandParser_Read(RingBuffer* buffer, uint8_t* target, uint8_t maxLength);

uint8_t CommandParser_ParseNewLine(uint8_t data);

inline uint8_t CommandParser_IsNewLine(uint8_t data);

#endif  //__COMMANDPARSER_H__
/* [] END OF FILE */
