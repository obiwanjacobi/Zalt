/*******************************************************************************
* File Name: BusDriver.c
* Version 1.30
*
* Description:
*  This file provides the source code to the API for the EMIF component
*
* Note:
*  None
*
********************************************************************************
* Copyright 2011-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "BusDriver.h"

uint8 BusDriver_initVar = 0u;


/*******************************************************************************
* Function Name: BusDriver_Init
********************************************************************************
*
* Summary:
*  Initializes the EMIF configuration to the current customizer state
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void BusDriver_Init(void) 
{
    /* Asynchronous External Memory EMIF Config */
    #if (BusDriver_MODE == BusDriver_ASYNCH)
        BusDriver_NO_UDB_REG = BusDriver_MODE_NOUDB;
        BusDriver_MEM_TYPE_REG = BusDriver_MEM_ASYNC;
        BusDriver_RD_WAIT_STATE_REG = BusDriver_READ_WTSTATES;
        BusDriver_WR_WAIT_STATE_REG = BusDriver_WRITE_WTSTATES;   
    
    /* Synchronous External Memory EMIF Config */
    #elif (BusDriver_MODE == BusDriver_SYNCH)
        BusDriver_NO_UDB_REG = BusDriver_MODE_NOUDB;
        BusDriver_MEM_PWR_REG = BusDriver_DEFAULT_STATE;
        BusDriver_MEM_TYPE_REG = BusDriver_MEM_SYNC;
        
        BusDriver_RD_WAIT_STATE_REG = BusDriver_READ_WTSTATES;
        BusDriver_WR_WAIT_STATE_REG = BusDriver_WRITE_WTSTATES;   
    
    /* Custom External Memory EMIF Config */
    #else
        BusDriver_NO_UDB_REG = BusDriver_MODE_UDB;
    #endif /* End of BusDriver_MODE configuration */

    /* EMIF clock divider */
   BusDriver_CLK_DIV_REG = BusDriver_CLOCK_DIV;
}


/*******************************************************************************
* Function Name: BusDriver_Enable
********************************************************************************
*
* Summary:
*  Enables the EMIF hardware block, associated IO ports and pins, and for 
*  custom mode associated UDB logic
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void BusDriver_Enable(void) 
{
    uint8 enableInterrupts;
    
    /* Change Power regs, need to be safety */
    enableInterrupts = CyEnterCriticalSection();
    
    BusDriver_POWER_REG |= BusDriver_POWER_ON;
    BusDriver_STBY_REG  |= BusDriver_POWER_ON;
                
    /* Power regs config are done */
    CyExitCriticalSection(enableInterrupts);

    /* Enable Clock tp EMIF */
    BusDriver_ENABLE_REG |= BusDriver_ENABLE;
}


/*******************************************************************************
* Function Name: BusDriver_Start
********************************************************************************
*
* Summary:
*  Initializes the EMIF configuration to the current customizer state.
*  Enables the EMIF hardware block, associated IO ports and pins
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  BusDriver_initVar - used to check initial configuration, modified on 
*  first function call.
*
*******************************************************************************/
void BusDriver_Start(void) 
{
    if (BusDriver_initVar == 0u)
    {
        BusDriver_Init();
        BusDriver_initVar = 1u;
    }
    
    BusDriver_Enable();
}


/*******************************************************************************
* Function Name: BusDriver_Stop
********************************************************************************
*
* Summary:
*  Disables the EMIF block and associated UDB logic (custom mode). 
*  Returns all associated IO ports and pins to Hi-Z mode.  
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void BusDriver_Stop(void) 
{
    uint8 enableInterrupts;
    
    /* Stop EMIF Clock */    
    BusDriver_ENABLE_REG = BusDriver_DEFAULT_STATE;

    /* Change Power regs, need to be safety */
    enableInterrupts = CyEnterCriticalSection();

    BusDriver_POWER_REG &= ((uint8)~BusDriver_POWER_ON);
    BusDriver_STBY_REG  &= ((uint8)~BusDriver_POWER_ON);
                
    /* Power regs config are done */
    CyExitCriticalSection(enableInterrupts);
    
}


/*******************************************************************************
* Function Name: BusDriver_ExtMemSleep
********************************************************************************
*
* Summary:
*  Sets the 'mem_pd' bit in the EMIF_PWR_DWN register. This sets the external 
*  memory sleep signal high; note that depending on the type of external memory 
*  IC used the signal may need to be inverted.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Reentrant:
*  No
*
*******************************************************************************/
void BusDriver_ExtMemSleep(void) 
{
    #if (BusDriver_MODE == BusDriver_SYNCH)
        BusDriver_MEM_PWR_REG = BusDriver_MEM_PWR_DOWN;
    #endif /* End BusDriver_MODE == BusDriver_SYNCH */
}


/*******************************************************************************
* Function Name: BusDriver_ExtMemWakeup
********************************************************************************
*
* Summary:
*  Resets the 'mem_pd' bit in the EMIF_PWR_DWN register. This sets the 
*  external memory sleep signal low; note that depending on the type of 
*  external memory IC used the signal may need to be inverted.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/

void BusDriver_ExtMemWakeup(void) 
{
    #if (BusDriver_MODE == BusDriver_SYNCH)
        BusDriver_MEM_PWR_REG = BusDriver_DEFAULT_STATE;
    #endif /* End BusDriver_MODE == BusDriver_SYNCH */
}

/* [] END OF FILE */
