/*******************************************************************************
* File Name: Data.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Data_ALIASES_H) /* Pins Data_ALIASES_H */
#define CY_PINS_Data_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"



/***************************************
*              Constants        
***************************************/
#define Data_0		(Data__0__PC)
#define Data_1		(Data__1__PC)
#define Data_2		(Data__2__PC)
#define Data_3		(Data__3__PC)
#define Data_4		(Data__4__PC)
#define Data_5		(Data__5__PC)
#define Data_6		(Data__6__PC)
#define Data_7		(Data__7__PC)

#endif /* End Pins Data_ALIASES_H */

/* [] END OF FILE */
