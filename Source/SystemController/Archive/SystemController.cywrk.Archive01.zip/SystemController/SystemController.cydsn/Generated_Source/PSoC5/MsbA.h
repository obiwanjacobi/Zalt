/*******************************************************************************
* File Name: MsbA.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_MsbA_H) /* Pins MsbA_H */
#define CY_PINS_MsbA_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "MsbA_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 MsbA__PORT == 15 && ((MsbA__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    MsbA_Write(uint8 value) ;
void    MsbA_SetDriveMode(uint8 mode) ;
uint8   MsbA_ReadDataReg(void) ;
uint8   MsbA_Read(void) ;
uint8   MsbA_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define MsbA_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define MsbA_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define MsbA_DM_RES_UP          PIN_DM_RES_UP
#define MsbA_DM_RES_DWN         PIN_DM_RES_DWN
#define MsbA_DM_OD_LO           PIN_DM_OD_LO
#define MsbA_DM_OD_HI           PIN_DM_OD_HI
#define MsbA_DM_STRONG          PIN_DM_STRONG
#define MsbA_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define MsbA_MASK               MsbA__MASK
#define MsbA_SHIFT              MsbA__SHIFT
#define MsbA_WIDTH              8u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define MsbA_PS                     (* (reg8 *) MsbA__PS)
/* Data Register */
#define MsbA_DR                     (* (reg8 *) MsbA__DR)
/* Port Number */
#define MsbA_PRT_NUM                (* (reg8 *) MsbA__PRT) 
/* Connect to Analog Globals */                                                  
#define MsbA_AG                     (* (reg8 *) MsbA__AG)                       
/* Analog MUX bux enable */
#define MsbA_AMUX                   (* (reg8 *) MsbA__AMUX) 
/* Bidirectional Enable */                                                        
#define MsbA_BIE                    (* (reg8 *) MsbA__BIE)
/* Bit-mask for Aliased Register Access */
#define MsbA_BIT_MASK               (* (reg8 *) MsbA__BIT_MASK)
/* Bypass Enable */
#define MsbA_BYP                    (* (reg8 *) MsbA__BYP)
/* Port wide control signals */                                                   
#define MsbA_CTL                    (* (reg8 *) MsbA__CTL)
/* Drive Modes */
#define MsbA_DM0                    (* (reg8 *) MsbA__DM0) 
#define MsbA_DM1                    (* (reg8 *) MsbA__DM1)
#define MsbA_DM2                    (* (reg8 *) MsbA__DM2) 
/* Input Buffer Disable Override */
#define MsbA_INP_DIS                (* (reg8 *) MsbA__INP_DIS)
/* LCD Common or Segment Drive */
#define MsbA_LCD_COM_SEG            (* (reg8 *) MsbA__LCD_COM_SEG)
/* Enable Segment LCD */
#define MsbA_LCD_EN                 (* (reg8 *) MsbA__LCD_EN)
/* Slew Rate Control */
#define MsbA_SLW                    (* (reg8 *) MsbA__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define MsbA_PRTDSI__CAPS_SEL       (* (reg8 *) MsbA__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define MsbA_PRTDSI__DBL_SYNC_IN    (* (reg8 *) MsbA__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define MsbA_PRTDSI__OE_SEL0        (* (reg8 *) MsbA__PRTDSI__OE_SEL0) 
#define MsbA_PRTDSI__OE_SEL1        (* (reg8 *) MsbA__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define MsbA_PRTDSI__OUT_SEL0       (* (reg8 *) MsbA__PRTDSI__OUT_SEL0) 
#define MsbA_PRTDSI__OUT_SEL1       (* (reg8 *) MsbA__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define MsbA_PRTDSI__SYNC_OUT       (* (reg8 *) MsbA__PRTDSI__SYNC_OUT) 


#if defined(MsbA__INTSTAT)  /* Interrupt Registers */

    #define MsbA_INTSTAT                (* (reg8 *) MsbA__INTSTAT)
    #define MsbA_SNAP                   (* (reg8 *) MsbA__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_MsbA_H */


/* [] END OF FILE */
