#include "IOController.h"
#include "BusController.h"
#include "CpuController.h"

// global instance for ISR
static IOInfo g_isrData;

void IOController_Init()
{
    g_isrData.Address = 0;
    g_isrData.Data = 0;
    g_isrData.Mode = 0;
    ISR_SYS_IOREQ_Start();
}

inline void IOController_ISR_OnIOInterrupt()
{
    if (CpuController_IsResetActive()) return;
    uint8_t output = 0 == CyPins_ReadPin(ExtBus_Wr);
    g_isrData.Mode = output;
    g_isrData.Address = LsbA_Read();
    // not sure we need this register - perhaps read directly from the bus?
    g_isrData.Data = DataReg_Read();
    
    // we're being written to
    if (output)
    {
        // read from data bus and write to IO peripheral register
        IOController_Output(&g_isrData);
    }
    else    // input
    {
        BusController_EnableDataBusOutput(1);
        
        // read data in from perihpiral and write to data bus
        IOController_Input(&g_isrData);
        
        BusController_EnableDataBusOutput(0);
    }
}

inline void IOController_Output(IOInfo* ioInfo)
{
    switch(ioInfo->Mode)
    {
        case IO_TEST_LOOP:
            // no-op
            break;
        case IO_Serial:
            SysTerminal_PutChar(ioInfo->Data);
            break;
        default:
            break;
    }
}

inline void IOController_Input(IOInfo* ioInfo)
{
    uint8_t data = 0;
    
    switch(ioInfo->Mode)
    {
        case IO_TEST_LOOP:
            data = ioInfo->Data;
            break;
        case IO_Serial:
            data = SysTerminal_GetChar();
            break;
        default:
            break;
    }
    
    D_Write(data);
}

/* [] END OF FILE */
