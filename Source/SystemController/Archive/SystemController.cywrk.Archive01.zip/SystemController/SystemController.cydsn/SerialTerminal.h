#ifndef __SERIALTERMINAL_H__
#define __SERIALTERMINAL_H__

#include <project.h>
#include "RingBuffer.h"
    
typedef struct 
{
    RingBuffer RxBuffer;
    
} SerialTerminal;

void SerialTerminal_Start(SerialTerminal* serialTerminal);

uint16_t SerialTerminal_ReceiveCommand(SerialTerminal* serialTerminal);

typedef uint8_t (ReceiveCallback)(void* ctx, uint8_t data);
uint16_t SerialTerminal_ReceiveBlob(void* ctx, ReceiveCallback fnCallback);

void SerialTerminal_WriteLine(const char8* text);

#endif//__SERIALTERMINAL_H__

/* [] END OF FILE */
