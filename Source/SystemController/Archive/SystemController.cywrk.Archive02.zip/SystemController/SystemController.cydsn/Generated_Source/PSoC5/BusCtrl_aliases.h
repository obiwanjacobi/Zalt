/*******************************************************************************
* File Name: BusCtrl.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BusCtrl_ALIASES_H) /* Pins BusCtrl_ALIASES_H */
#define CY_PINS_BusCtrl_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"



/***************************************
*              Constants        
***************************************/
#define BusCtrl_0		(BusCtrl__0__PC)
#define BusCtrl_1		(BusCtrl__1__PC)
#define BusCtrl_2		(BusCtrl__2__PC)
#define BusCtrl_3		(BusCtrl__3__PC)
#define BusCtrl_4		(BusCtrl__4__PC)
#define BusCtrl_5		(BusCtrl__5__PC)
#define BusCtrl_6		(BusCtrl__6__PC)
#define BusCtrl_7		(BusCtrl__7__PC)
#define BusCtrl_8		(BusCtrl__8__PC)

#define BusCtrl_MEMREQ		(BusCtrl__MEMREQ__PC)
#define BusCtrl_IOREQ		(BusCtrl__IOREQ__PC)
#define BusCtrl_RD		(BusCtrl__RD__PC)
#define BusCtrl_WR		(BusCtrl__WR__PC)
#define BusCtrl_BUSREQ		(BusCtrl__BUSREQ__PC)
#define BusCtrl_BUSACK		(BusCtrl__BUSACK__PC)
#define BusCtrl_HALT		(BusCtrl__HALT__PC)
#define BusCtrl_CPURST		(BusCtrl__CPURST__PC)
#define BusCtrl_CPUCLK		(BusCtrl__CPUCLK__PC)

#endif /* End Pins BusCtrl_ALIASES_H */

/* [] END OF FILE */
