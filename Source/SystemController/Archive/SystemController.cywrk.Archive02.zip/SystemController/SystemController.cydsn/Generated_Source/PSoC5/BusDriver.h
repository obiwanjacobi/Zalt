/*******************************************************************************
* File Name: BusDriver.h
* Version 1.30
*
* Description:
*  This file provides constants and parameter values for the EMIF component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2011-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_EMIF_BusDriver_H)
#define CY_EMIF_BusDriver_H

#include "BusDriver.h"
#include "cyfitter.h"
#include "CyLib.h"


/***************************************
*   Conditional Compilation Parameters
****************************************/

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */

#if !defined (CY_PSOC5A)
    #error Component EMIF_v1_30 requires cy_boot v3.0 or later
#endif /* (CY_ PSOC5A) */

#define BusDriver_DATA_SIZE      (8u)
#define BusDriver_ADDR_SIZE      (16u)
#define BusDriver_MEM_SPEED      (30u)
#define BusDriver_MODE           (0u)

/* EMIF Modes */
#define BusDriver_CUSTOM (2u)
#define BusDriver_ASYNCH (0u)
#define BusDriver_SYNCH  (1u)

extern uint8 BusDriver_initVar;


/***************************************
*       Type defines
***************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} BusDriver_BACKUP_STRUCT;


/***************************************
*        Function Prototypes
****************************************/

void BusDriver_Init(void) ;
void BusDriver_Enable(void) ;
void BusDriver_Start(void) ;
void BusDriver_Stop(void) ;
void BusDriver_SaveConfig(void) ;
void BusDriver_RestoreConfig(void) ;
void BusDriver_Sleep(void) ;
void BusDriver_Wakeup(void) ;
void BusDriver_ExtMemSleep(void) ;
void BusDriver_ExtMemWakeup(void) ;


/***************************************
*    Initial Parameter Constants
***************************************/


/***************************************
*           API Constants
***************************************/

#define BusDriver_CLOCK_DIV          (0u)
#define BusDriver_READ_WTSTATES      (1u)
#define BusDriver_WRITE_WTSTATES     (0u)


/***************************************
*             Registers
***************************************/

#define BusDriver_ENABLE_REG         (*(reg8 *)   BusDriver_EMIF_ES3__CLOCK_EN)
#define BusDriver_ENABLE_PTR         ( (reg8 *)   BusDriver_EMIF_ES3__CLOCK_EN)

#define BusDriver_MEM_TYPE_REG       (*(reg8 *)   BusDriver_EMIF_ES3__EM_TYPE)
#define BusDriver_MEM_TYPE_PTR       ( (reg8 *)   BusDriver_EMIF_ES3__EM_TYPE)

#if (BusDriver_MODE == BusDriver_SYNCH)
    #define BusDriver_MEM_PWR_REG        (*(reg8 *)   BusDriver_EMIF_ES3__MEM_DWN)
    #define BusDriver_MEM_PWR_PTR        ( (reg8 *)   BusDriver_EMIF_ES3__MEM_DWN)
#endif /* End BusDriver_MODE == BusDriver_SYNCH */

#define BusDriver_CLK_DIV_REG        (*(reg8 *)   BusDriver_EMIF_ES3__MEMCLK_DIV)
#define BusDriver_CLK_DIV_PTR        ( (reg8 *)   BusDriver_EMIF_ES3__MEMCLK_DIV)

#define BusDriver_NO_UDB_REG         (*(reg8 *)   BusDriver_EMIF_ES3__NO_UDB)
#define BusDriver_NO_UDB_PTR         ( (reg8 *)   BusDriver_EMIF_ES3__NO_UDB)

#define BusDriver_POWER_REG          (*(reg8 *)   BusDriver_EMIF_ES3__PM_ACT_CFG)
#define BusDriver_POWER_PTR          ( (reg8 *)   BusDriver_EMIF_ES3__PM_ACT_CFG)

#define BusDriver_STBY_REG           (*(reg8 *)   BusDriver_EMIF_ES3__PM_STBY_CFG)
#define BusDriver_STBY_PTR           ( (reg8 *)   BusDriver_EMIF_ES3__PM_STBY_CFG)

#define BusDriver_RD_WAIT_STATE_REG  (*(reg8 *)   BusDriver_EMIF_ES3__RP_WAIT_STATES)
#define BusDriver_RD_WAIT_STATE_PTR  ( (reg8 *)   BusDriver_EMIF_ES3__RP_WAIT_STATES)
    
#define BusDriver_WR_WAIT_STATE_REG  (*(reg8 *)   BusDriver_EMIF_ES3__WP_WAIT_STATES)
#define BusDriver_WR_WAIT_STATE_PTR  ( (reg8 *)   BusDriver_EMIF_ES3__WP_WAIT_STATES)


/***************************************
*       Register Constants
***************************************/

#define BusDriver_DEFAULT_STATE      (0x00u)
#define BusDriver_ENABLE             (0x01u)
#define BusDriver_MEM_SYNC           (0x00u)
#define BusDriver_MEM_ASYNC          (0x01u)
#define BusDriver_MODE_UDB           (0x00u)
#define BusDriver_MODE_NOUDB         (0x01u)
#define BusDriver_MEM_PWR_DOWN       (0x01u)
#define BusDriver_POWER_ON           (0x40u)


#endif  /* End CY_EMIF_BusDriver_H */


/* [] END OF FILE */
