/*******************************************************************************
* File Name: MsbA.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_MsbA_ALIASES_H) /* Pins MsbA_ALIASES_H */
#define CY_PINS_MsbA_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define MsbA_0			(MsbA__0__PC)
#define MsbA_0_INTR	((uint16)((uint16)0x0001u << MsbA__0__SHIFT))

#define MsbA_1			(MsbA__1__PC)
#define MsbA_1_INTR	((uint16)((uint16)0x0001u << MsbA__1__SHIFT))

#define MsbA_2			(MsbA__2__PC)
#define MsbA_2_INTR	((uint16)((uint16)0x0001u << MsbA__2__SHIFT))

#define MsbA_3			(MsbA__3__PC)
#define MsbA_3_INTR	((uint16)((uint16)0x0001u << MsbA__3__SHIFT))

#define MsbA_4			(MsbA__4__PC)
#define MsbA_4_INTR	((uint16)((uint16)0x0001u << MsbA__4__SHIFT))

#define MsbA_5			(MsbA__5__PC)
#define MsbA_5_INTR	((uint16)((uint16)0x0001u << MsbA__5__SHIFT))

#define MsbA_6			(MsbA__6__PC)
#define MsbA_6_INTR	((uint16)((uint16)0x0001u << MsbA__6__SHIFT))

#define MsbA_7			(MsbA__7__PC)
#define MsbA_7_INTR	((uint16)((uint16)0x0001u << MsbA__7__SHIFT))

#define MsbA_INTR_ALL	 ((uint16)(MsbA_0_INTR| MsbA_1_INTR| MsbA_2_INTR| MsbA_3_INTR| MsbA_4_INTR| MsbA_5_INTR| MsbA_6_INTR| MsbA_7_INTR))

#endif /* End Pins MsbA_ALIASES_H */


/* [] END OF FILE */
