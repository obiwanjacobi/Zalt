/*******************************************************************************
* File Name: STL.c
* Version 2.50
*
* Description:
*  This file provides all API functionality of the UART component
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "STL.h"
#if (STL_INTERNAL_CLOCK_USED)
    #include "STL_IntClock.h"
#endif /* End STL_INTERNAL_CLOCK_USED */


/***************************************
* Global data allocation
***************************************/

uint8 STL_initVar = 0u;

#if (STL_TX_INTERRUPT_ENABLED && STL_TX_ENABLED)
    volatile uint8 STL_txBuffer[STL_TX_BUFFER_SIZE];
    volatile uint8 STL_txBufferRead = 0u;
    uint8 STL_txBufferWrite = 0u;
#endif /* (STL_TX_INTERRUPT_ENABLED && STL_TX_ENABLED) */

#if (STL_RX_INTERRUPT_ENABLED && (STL_RX_ENABLED || STL_HD_ENABLED))
    uint8 STL_errorStatus = 0u;
    volatile uint8 STL_rxBuffer[STL_RX_BUFFER_SIZE];
    volatile uint8 STL_rxBufferRead  = 0u;
    volatile uint8 STL_rxBufferWrite = 0u;
    volatile uint8 STL_rxBufferLoopDetect = 0u;
    volatile uint8 STL_rxBufferOverflow   = 0u;
    #if (STL_RXHW_ADDRESS_ENABLED)
        volatile uint8 STL_rxAddressMode = STL_RX_ADDRESS_MODE;
        volatile uint8 STL_rxAddressDetected = 0u;
    #endif /* (STL_RXHW_ADDRESS_ENABLED) */
#endif /* (STL_RX_INTERRUPT_ENABLED && (STL_RX_ENABLED || STL_HD_ENABLED)) */


/*******************************************************************************
* Function Name: STL_Start
********************************************************************************
*
* Summary:
*  This is the preferred method to begin component operation.
*  STL_Start() sets the initVar variable, calls the
*  STL_Init() function, and then calls the
*  STL_Enable() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  The STL_intiVar variable is used to indicate initial
*  configuration of this component. The variable is initialized to zero (0u)
*  and set to one (1u) the first time STL_Start() is called. This
*  allows for component initialization without re-initialization in all
*  subsequent calls to the STL_Start() routine.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void STL_Start(void) 
{
    /* If not initialized then initialize all required hardware and software */
    if(STL_initVar == 0u)
    {
        STL_Init();
        STL_initVar = 1u;
    }

    STL_Enable();
}


/*******************************************************************************
* Function Name: STL_Init
********************************************************************************
*
* Summary:
*  Initializes or restores the component according to the customizer Configure
*  dialog settings. It is not necessary to call STL_Init() because
*  the STL_Start() API calls this function and is the preferred
*  method to begin component operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void STL_Init(void) 
{
    #if(STL_RX_ENABLED || STL_HD_ENABLED)

        #if (STL_RX_INTERRUPT_ENABLED)
            /* Set RX interrupt vector and priority */
            (void) CyIntSetVector(STL_RX_VECT_NUM, &STL_RXISR);
            CyIntSetPriority(STL_RX_VECT_NUM, STL_RX_PRIOR_NUM);
            STL_errorStatus = 0u;
        #endif /* (STL_RX_INTERRUPT_ENABLED) */

        #if (STL_RXHW_ADDRESS_ENABLED)
            STL_SetRxAddressMode(STL_RX_ADDRESS_MODE);
            STL_SetRxAddress1(STL_RX_HW_ADDRESS1);
            STL_SetRxAddress2(STL_RX_HW_ADDRESS2);
        #endif /* End STL_RXHW_ADDRESS_ENABLED */

        /* Init Count7 period */
        STL_RXBITCTR_PERIOD_REG = STL_RXBITCTR_INIT;
        /* Configure the Initial RX interrupt mask */
        STL_RXSTATUS_MASK_REG  = STL_INIT_RX_INTERRUPTS_MASK;
    #endif /* End STL_RX_ENABLED || STL_HD_ENABLED*/

    #if(STL_TX_ENABLED)
        #if (STL_TX_INTERRUPT_ENABLED)
            /* Set TX interrupt vector and priority */
            (void) CyIntSetVector(STL_TX_VECT_NUM, &STL_TXISR);
            CyIntSetPriority(STL_TX_VECT_NUM, STL_TX_PRIOR_NUM);
        #endif /* (STL_TX_INTERRUPT_ENABLED) */

        /* Write Counter Value for TX Bit Clk Generator*/
        #if (STL_TXCLKGEN_DP)
            STL_TXBITCLKGEN_CTR_REG = STL_BIT_CENTER;
            STL_TXBITCLKTX_COMPLETE_REG = ((STL_NUMBER_OF_DATA_BITS +
                        STL_NUMBER_OF_START_BIT) * STL_OVER_SAMPLE_COUNT) - 1u;
        #else
            STL_TXBITCTR_PERIOD_REG = ((STL_NUMBER_OF_DATA_BITS +
                        STL_NUMBER_OF_START_BIT) * STL_OVER_SAMPLE_8) - 1u;
        #endif /* End STL_TXCLKGEN_DP */

        /* Configure the Initial TX interrupt mask */
        #if (STL_TX_INTERRUPT_ENABLED)
            STL_TXSTATUS_MASK_REG = STL_TX_STS_FIFO_EMPTY;
        #else
            STL_TXSTATUS_MASK_REG = STL_INIT_TX_INTERRUPTS_MASK;
        #endif /*End STL_TX_INTERRUPT_ENABLED*/

    #endif /* End STL_TX_ENABLED */

    #if(STL_PARITY_TYPE_SW)  /* Write Parity to Control Register */
        STL_WriteControlRegister( \
            (STL_ReadControlRegister() & (uint8)~STL_CTRL_PARITY_TYPE_MASK) | \
            (uint8)(STL_PARITY_TYPE << STL_CTRL_PARITY_TYPE0_SHIFT) );
    #endif /* End STL_PARITY_TYPE_SW */
}


/*******************************************************************************
* Function Name: STL_Enable
********************************************************************************
*
* Summary:
*  Activates the hardware and begins component operation. It is not necessary
*  to call STL_Enable() because the STL_Start() API
*  calls this function, which is the preferred method to begin component
*  operation.

* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  STL_rxAddressDetected - set to initial state (0).
*
*******************************************************************************/
void STL_Enable(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    #if (STL_RX_ENABLED || STL_HD_ENABLED)
        /* RX Counter (Count7) Enable */
        STL_RXBITCTR_CONTROL_REG |= STL_CNTR_ENABLE;

        /* Enable the RX Interrupt */
        STL_RXSTATUS_ACTL_REG  |= STL_INT_ENABLE;

        #if (STL_RX_INTERRUPT_ENABLED)
            STL_EnableRxInt();

            #if (STL_RXHW_ADDRESS_ENABLED)
                STL_rxAddressDetected = 0u;
            #endif /* (STL_RXHW_ADDRESS_ENABLED) */
        #endif /* (STL_RX_INTERRUPT_ENABLED) */
    #endif /* (STL_RX_ENABLED || STL_HD_ENABLED) */

    #if(STL_TX_ENABLED)
        /* TX Counter (DP/Count7) Enable */
        #if(!STL_TXCLKGEN_DP)
            STL_TXBITCTR_CONTROL_REG |= STL_CNTR_ENABLE;
        #endif /* End STL_TXCLKGEN_DP */

        /* Enable the TX Interrupt */
        STL_TXSTATUS_ACTL_REG |= STL_INT_ENABLE;
        #if (STL_TX_INTERRUPT_ENABLED)
            STL_ClearPendingTxInt(); /* Clear history of TX_NOT_EMPTY */
            STL_EnableTxInt();
        #endif /* (STL_TX_INTERRUPT_ENABLED) */
     #endif /* (STL_TX_INTERRUPT_ENABLED) */

    #if (STL_INTERNAL_CLOCK_USED)
        STL_IntClock_Start();  /* Enable the clock */
    #endif /* (STL_INTERNAL_CLOCK_USED) */

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: STL_Stop
********************************************************************************
*
* Summary:
*  Disables the UART operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void STL_Stop(void) 
{
    uint8 enableInterrupts;
    enableInterrupts = CyEnterCriticalSection();

    /* Write Bit Counter Disable */
    #if (STL_RX_ENABLED || STL_HD_ENABLED)
        STL_RXBITCTR_CONTROL_REG &= (uint8) ~STL_CNTR_ENABLE;
    #endif /* (STL_RX_ENABLED || STL_HD_ENABLED) */

    #if (STL_TX_ENABLED)
        #if(!STL_TXCLKGEN_DP)
            STL_TXBITCTR_CONTROL_REG &= (uint8) ~STL_CNTR_ENABLE;
        #endif /* (!STL_TXCLKGEN_DP) */
    #endif /* (STL_TX_ENABLED) */

    #if (STL_INTERNAL_CLOCK_USED)
        STL_IntClock_Stop();   /* Disable the clock */
    #endif /* (STL_INTERNAL_CLOCK_USED) */

    /* Disable internal interrupt component */
    #if (STL_RX_ENABLED || STL_HD_ENABLED)
        STL_RXSTATUS_ACTL_REG  &= (uint8) ~STL_INT_ENABLE;

        #if (STL_RX_INTERRUPT_ENABLED)
            STL_DisableRxInt();
        #endif /* (STL_RX_INTERRUPT_ENABLED) */
    #endif /* (STL_RX_ENABLED || STL_HD_ENABLED) */

    #if (STL_TX_ENABLED)
        STL_TXSTATUS_ACTL_REG &= (uint8) ~STL_INT_ENABLE;

        #if (STL_TX_INTERRUPT_ENABLED)
            STL_DisableTxInt();
        #endif /* (STL_TX_INTERRUPT_ENABLED) */
    #endif /* (STL_TX_ENABLED) */

    CyExitCriticalSection(enableInterrupts);
}


/*******************************************************************************
* Function Name: STL_ReadControlRegister
********************************************************************************
*
* Summary:
*  Returns the current value of the control register.
*
* Parameters:
*  None.
*
* Return:
*  Contents of the control register.
*
*******************************************************************************/
uint8 STL_ReadControlRegister(void) 
{
    #if (STL_CONTROL_REG_REMOVED)
        return(0u);
    #else
        return(STL_CONTROL_REG);
    #endif /* (STL_CONTROL_REG_REMOVED) */
}


/*******************************************************************************
* Function Name: STL_WriteControlRegister
********************************************************************************
*
* Summary:
*  Writes an 8-bit value into the control register
*
* Parameters:
*  control:  control register value
*
* Return:
*  None.
*
*******************************************************************************/
void  STL_WriteControlRegister(uint8 control) 
{
    #if (STL_CONTROL_REG_REMOVED)
        if(0u != control)
        {
            /* Suppress compiler warning */
        }
    #else
       STL_CONTROL_REG = control;
    #endif /* (STL_CONTROL_REG_REMOVED) */
}


#if(STL_RX_ENABLED || STL_HD_ENABLED)
    /*******************************************************************************
    * Function Name: STL_SetRxInterruptMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the RX interrupt sources enabled.
    *
    * Parameters:
    *  IntSrc:  Bit field containing the RX interrupts to enable. Based on the 
    *  bit-field arrangement of the status register. This value must be a 
    *  combination of status register bit-masks shown below:
    *      STL_RX_STS_FIFO_NOTEMPTY    Interrupt on byte received.
    *      STL_RX_STS_PAR_ERROR        Interrupt on parity error.
    *      STL_RX_STS_STOP_ERROR       Interrupt on stop error.
    *      STL_RX_STS_BREAK            Interrupt on break.
    *      STL_RX_STS_OVERRUN          Interrupt on overrun error.
    *      STL_RX_STS_ADDR_MATCH       Interrupt on address match.
    *      STL_RX_STS_MRKSPC           Interrupt on address detect.
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Enables the output of specific status bits to the interrupt controller
    *
    *******************************************************************************/
    void STL_SetRxInterruptMode(uint8 intSrc) 
    {
        STL_RXSTATUS_MASK_REG  = intSrc;
    }


    /*******************************************************************************
    * Function Name: STL_ReadRxData
    ********************************************************************************
    *
    * Summary:
    *  Returns the next byte of received data. This function returns data without
    *  checking the status. You must check the status separately.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Received data from RX register
    *
    * Global Variables:
    *  STL_rxBuffer - RAM buffer pointer for save received data.
    *  STL_rxBufferWrite - cyclic index for write to rxBuffer,
    *     checked to identify new data.
    *  STL_rxBufferRead - cyclic index for read from rxBuffer,
    *     incremented after each byte has been read from buffer.
    *  STL_rxBufferLoopDetect - cleared if loop condition was detected
    *     in RX ISR.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint8 STL_ReadRxData(void) 
    {
        uint8 rxData;

    #if (STL_RX_INTERRUPT_ENABLED)

        uint8 locRxBufferRead;
        uint8 locRxBufferWrite;

        /* Protect variables that could change on interrupt */
        STL_DisableRxInt();

        locRxBufferRead  = STL_rxBufferRead;
        locRxBufferWrite = STL_rxBufferWrite;

        if( (STL_rxBufferLoopDetect != 0u) || (locRxBufferRead != locRxBufferWrite) )
        {
            rxData = STL_rxBuffer[locRxBufferRead];
            locRxBufferRead++;

            if(locRxBufferRead >= STL_RX_BUFFER_SIZE)
            {
                locRxBufferRead = 0u;
            }
            /* Update the real pointer */
            STL_rxBufferRead = locRxBufferRead;

            if(STL_rxBufferLoopDetect != 0u)
            {
                STL_rxBufferLoopDetect = 0u;
                #if ((STL_RX_INTERRUPT_ENABLED) && (STL_FLOW_CONTROL != 0u))
                    /* When Hardware Flow Control selected - return RX mask */
                    #if( STL_HD_ENABLED )
                        if((STL_CONTROL_REG & STL_CTRL_HD_SEND) == 0u)
                        {   /* In Half duplex mode return RX mask only in RX
                            *  configuration set, otherwise
                            *  mask will be returned in LoadRxConfig() API.
                            */
                            STL_RXSTATUS_MASK_REG  |= STL_RX_STS_FIFO_NOTEMPTY;
                        }
                    #else
                        STL_RXSTATUS_MASK_REG  |= STL_RX_STS_FIFO_NOTEMPTY;
                    #endif /* end STL_HD_ENABLED */
                #endif /* ((STL_RX_INTERRUPT_ENABLED) && (STL_FLOW_CONTROL != 0u)) */
            }
        }
        else
        {   /* Needs to check status for RX_STS_FIFO_NOTEMPTY bit */
            rxData = STL_RXDATA_REG;
        }

        STL_EnableRxInt();

    #else

        /* Needs to check status for RX_STS_FIFO_NOTEMPTY bit */
        rxData = STL_RXDATA_REG;

    #endif /* (STL_RX_INTERRUPT_ENABLED) */

        return(rxData);
    }


    /*******************************************************************************
    * Function Name: STL_ReadRxStatus
    ********************************************************************************
    *
    * Summary:
    *  Returns the current state of the receiver status register and the software
    *  buffer overflow status.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Current state of the status register.
    *
    * Side Effect:
    *  All status register bits are clear-on-read except
    *  STL_RX_STS_FIFO_NOTEMPTY.
    *  STL_RX_STS_FIFO_NOTEMPTY clears immediately after RX data
    *  register read.
    *
    * Global Variables:
    *  STL_rxBufferOverflow - used to indicate overload condition.
    *   It set to one in RX interrupt when there isn't free space in
    *   STL_rxBufferRead to write new data. This condition returned
    *   and cleared to zero by this API as an
    *   STL_RX_STS_SOFT_BUFF_OVER bit along with RX Status register
    *   bits.
    *
    *******************************************************************************/
    uint8 STL_ReadRxStatus(void) 
    {
        uint8 status;

        status = STL_RXSTATUS_REG & STL_RX_HW_MASK;

    #if (STL_RX_INTERRUPT_ENABLED)
        if(STL_rxBufferOverflow != 0u)
        {
            status |= STL_RX_STS_SOFT_BUFF_OVER;
            STL_rxBufferOverflow = 0u;
        }
    #endif /* (STL_RX_INTERRUPT_ENABLED) */

        return(status);
    }


    /*******************************************************************************
    * Function Name: STL_GetChar
    ********************************************************************************
    *
    * Summary:
    *  Returns the last received byte of data. STL_GetChar() is
    *  designed for ASCII characters and returns a uint8 where 1 to 255 are values
    *  for valid characters and 0 indicates an error occurred or no data is present.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Character read from UART RX buffer. ASCII characters from 1 to 255 are valid.
    *  A returned zero signifies an error condition or no data available.
    *
    * Global Variables:
    *  STL_rxBuffer - RAM buffer pointer for save received data.
    *  STL_rxBufferWrite - cyclic index for write to rxBuffer,
    *     checked to identify new data.
    *  STL_rxBufferRead - cyclic index for read from rxBuffer,
    *     incremented after each byte has been read from buffer.
    *  STL_rxBufferLoopDetect - cleared if loop condition was detected
    *     in RX ISR.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint8 STL_GetChar(void) 
    {
        uint8 rxData = 0u;
        uint8 rxStatus;

    #if (STL_RX_INTERRUPT_ENABLED)
        uint8 locRxBufferRead;
        uint8 locRxBufferWrite;

        /* Protect variables that could change on interrupt */
        STL_DisableRxInt();

        locRxBufferRead  = STL_rxBufferRead;
        locRxBufferWrite = STL_rxBufferWrite;

        if( (STL_rxBufferLoopDetect != 0u) || (locRxBufferRead != locRxBufferWrite) )
        {
            rxData = STL_rxBuffer[locRxBufferRead];
            locRxBufferRead++;
            if(locRxBufferRead >= STL_RX_BUFFER_SIZE)
            {
                locRxBufferRead = 0u;
            }
            /* Update the real pointer */
            STL_rxBufferRead = locRxBufferRead;

            if(STL_rxBufferLoopDetect != 0u)
            {
                STL_rxBufferLoopDetect = 0u;
                #if( (STL_RX_INTERRUPT_ENABLED) && (STL_FLOW_CONTROL != 0u) )
                    /* When Hardware Flow Control selected - return RX mask */
                    #if( STL_HD_ENABLED )
                        if((STL_CONTROL_REG & STL_CTRL_HD_SEND) == 0u)
                        {   /* In Half duplex mode return RX mask only if
                            *  RX configuration set, otherwise
                            *  mask will be returned in LoadRxConfig() API.
                            */
                            STL_RXSTATUS_MASK_REG |= STL_RX_STS_FIFO_NOTEMPTY;
                        }
                    #else
                        STL_RXSTATUS_MASK_REG |= STL_RX_STS_FIFO_NOTEMPTY;
                    #endif /* end STL_HD_ENABLED */
                #endif /* STL_RX_INTERRUPT_ENABLED and Hardware flow control*/
            }

        }
        else
        {   rxStatus = STL_RXSTATUS_REG;
            if((rxStatus & STL_RX_STS_FIFO_NOTEMPTY) != 0u)
            {   /* Read received data from FIFO */
                rxData = STL_RXDATA_REG;
                /*Check status on error*/
                if((rxStatus & (STL_RX_STS_BREAK | STL_RX_STS_PAR_ERROR |
                                STL_RX_STS_STOP_ERROR | STL_RX_STS_OVERRUN)) != 0u)
                {
                    rxData = 0u;
                }
            }
        }

        STL_EnableRxInt();

    #else

        rxStatus =STL_RXSTATUS_REG;
        if((rxStatus & STL_RX_STS_FIFO_NOTEMPTY) != 0u)
        {
            /* Read received data from FIFO */
            rxData = STL_RXDATA_REG;

            /*Check status on error*/
            if((rxStatus & (STL_RX_STS_BREAK | STL_RX_STS_PAR_ERROR |
                            STL_RX_STS_STOP_ERROR | STL_RX_STS_OVERRUN)) != 0u)
            {
                rxData = 0u;
            }
        }
    #endif /* (STL_RX_INTERRUPT_ENABLED) */

        return(rxData);
    }


    /*******************************************************************************
    * Function Name: STL_GetByte
    ********************************************************************************
    *
    * Summary:
    *  Reads UART RX buffer immediately, returns received character and error
    *  condition.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  MSB contains status and LSB contains UART RX data. If the MSB is nonzero,
    *  an error has occurred.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    uint16 STL_GetByte(void) 
    {
        
    #if (STL_RX_INTERRUPT_ENABLED)
        uint16 locErrorStatus;
        /* Protect variables that could change on interrupt */
        STL_DisableRxInt();
        locErrorStatus = (uint16)STL_errorStatus;
        STL_errorStatus = 0u;
        STL_EnableRxInt();
        return ( (uint16)(locErrorStatus << 8u) | STL_ReadRxData() );
    #else
        return ( ((uint16)STL_ReadRxStatus() << 8u) | STL_ReadRxData() );
    #endif /* STL_RX_INTERRUPT_ENABLED */
        
    }


    /*******************************************************************************
    * Function Name: STL_GetRxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of received bytes available in the RX buffer.
    *  * RX software buffer is disabled (RX Buffer Size parameter is equal to 4): 
    *    returns 0 for empty RX FIFO or 1 for not empty RX FIFO.
    *  * RX software buffer is enabled: returns the number of bytes available in 
    *    the RX software buffer. Bytes available in the RX FIFO do not take to 
    *    account.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  uint8: Number of bytes in the RX buffer. 
    *    Return value type depends on RX Buffer Size parameter.
    *
    * Global Variables:
    *  STL_rxBufferWrite - used to calculate left bytes.
    *  STL_rxBufferRead - used to calculate left bytes.
    *  STL_rxBufferLoopDetect - checked to decide left bytes amount.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to find out how full the RX Buffer is.
    *
    *******************************************************************************/
    uint8 STL_GetRxBufferSize(void)
                                                            
    {
        uint8 size;

    #if (STL_RX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt */
        STL_DisableRxInt();

        if(STL_rxBufferRead == STL_rxBufferWrite)
        {
            if(STL_rxBufferLoopDetect != 0u)
            {
                size = STL_RX_BUFFER_SIZE;
            }
            else
            {
                size = 0u;
            }
        }
        else if(STL_rxBufferRead < STL_rxBufferWrite)
        {
            size = (STL_rxBufferWrite - STL_rxBufferRead);
        }
        else
        {
            size = (STL_RX_BUFFER_SIZE - STL_rxBufferRead) + STL_rxBufferWrite;
        }

        STL_EnableRxInt();

    #else

        /* We can only know if there is data in the fifo. */
        size = ((STL_RXSTATUS_REG & STL_RX_STS_FIFO_NOTEMPTY) != 0u) ? 1u : 0u;

    #endif /* (STL_RX_INTERRUPT_ENABLED) */

        return(size);
    }


    /*******************************************************************************
    * Function Name: STL_ClearRxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clears the receiver memory buffer and hardware RX FIFO of all received data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  STL_rxBufferWrite - cleared to zero.
    *  STL_rxBufferRead - cleared to zero.
    *  STL_rxBufferLoopDetect - cleared to zero.
    *  STL_rxBufferOverflow - cleared to zero.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Setting the pointers to zero makes the system believe there is no data to
    *  read and writing will resume at address 0 overwriting any data that may
    *  have remained in the RAM.
    *
    * Side Effects:
    *  Any received data not read from the RAM or FIFO buffer will be lost.
    *
    *******************************************************************************/
    void STL_ClearRxBuffer(void) 
    {
        uint8 enableInterrupts;

        /* Clear the HW FIFO */
        enableInterrupts = CyEnterCriticalSection();
        STL_RXDATA_AUX_CTL_REG |= (uint8)  STL_RX_FIFO_CLR;
        STL_RXDATA_AUX_CTL_REG &= (uint8) ~STL_RX_FIFO_CLR;
        CyExitCriticalSection(enableInterrupts);

    #if (STL_RX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        STL_DisableRxInt();

        STL_rxBufferRead = 0u;
        STL_rxBufferWrite = 0u;
        STL_rxBufferLoopDetect = 0u;
        STL_rxBufferOverflow = 0u;

        STL_EnableRxInt();

    #endif /* (STL_RX_INTERRUPT_ENABLED) */

    }


    /*******************************************************************************
    * Function Name: STL_SetRxAddressMode
    ********************************************************************************
    *
    * Summary:
    *  Sets the software controlled Addressing mode used by the RX portion of the
    *  UART.
    *
    * Parameters:
    *  addressMode: Enumerated value indicating the mode of RX addressing
    *  STL__B_UART__AM_SW_BYTE_BYTE -  Software Byte-by-Byte address
    *                                               detection
    *  STL__B_UART__AM_SW_DETECT_TO_BUFFER - Software Detect to Buffer
    *                                               address detection
    *  STL__B_UART__AM_HW_BYTE_BY_BYTE - Hardware Byte-by-Byte address
    *                                               detection
    *  STL__B_UART__AM_HW_DETECT_TO_BUFFER - Hardware Detect to Buffer
    *                                               address detection
    *  STL__B_UART__AM_NONE - No address detection
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  STL_rxAddressMode - the parameter stored in this variable for
    *   the farther usage in RX ISR.
    *  STL_rxAddressDetected - set to initial state (0).
    *
    *******************************************************************************/
    void STL_SetRxAddressMode(uint8 addressMode)
                                                        
    {
        #if(STL_RXHW_ADDRESS_ENABLED)
            #if(STL_CONTROL_REG_REMOVED)
                if(0u != addressMode)
                {
                    /* Suppress compiler warning */
                }
            #else /* STL_CONTROL_REG_REMOVED */
                uint8 tmpCtrl;
                tmpCtrl = STL_CONTROL_REG & (uint8)~STL_CTRL_RXADDR_MODE_MASK;
                tmpCtrl |= (uint8)(addressMode << STL_CTRL_RXADDR_MODE0_SHIFT);
                STL_CONTROL_REG = tmpCtrl;

                #if(STL_RX_INTERRUPT_ENABLED && \
                   (STL_RXBUFFERSIZE > STL_FIFO_LENGTH) )
                    STL_rxAddressMode = addressMode;
                    STL_rxAddressDetected = 0u;
                #endif /* End STL_RXBUFFERSIZE > STL_FIFO_LENGTH*/
            #endif /* End STL_CONTROL_REG_REMOVED */
        #else /* STL_RXHW_ADDRESS_ENABLED */
            if(0u != addressMode)
            {
                /* Suppress compiler warning */
            }
        #endif /* End STL_RXHW_ADDRESS_ENABLED */
    }


    /*******************************************************************************
    * Function Name: STL_SetRxAddress1
    ********************************************************************************
    *
    * Summary:
    *  Sets the first of two hardware-detectable receiver addresses.
    *
    * Parameters:
    *  address: Address #1 for hardware address detection.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    void STL_SetRxAddress1(uint8 address) 
    {
        STL_RXADDRESS1_REG = address;
    }


    /*******************************************************************************
    * Function Name: STL_SetRxAddress2
    ********************************************************************************
    *
    * Summary:
    *  Sets the second of two hardware-detectable receiver addresses.
    *
    * Parameters:
    *  address: Address #2 for hardware address detection.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    void STL_SetRxAddress2(uint8 address) 
    {
        STL_RXADDRESS2_REG = address;
    }

#endif  /* STL_RX_ENABLED || STL_HD_ENABLED*/


#if( (STL_TX_ENABLED) || (STL_HD_ENABLED) )
    /*******************************************************************************
    * Function Name: STL_SetTxInterruptMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the TX interrupt sources to be enabled, but does not enable the
    *  interrupt.
    *
    * Parameters:
    *  intSrc: Bit field containing the TX interrupt sources to enable
    *   STL_TX_STS_COMPLETE        Interrupt on TX byte complete
    *   STL_TX_STS_FIFO_EMPTY      Interrupt when TX FIFO is empty
    *   STL_TX_STS_FIFO_FULL       Interrupt when TX FIFO is full
    *   STL_TX_STS_FIFO_NOT_FULL   Interrupt when TX FIFO is not full
    *
    * Return:
    *  None.
    *
    * Theory:
    *  Enables the output of specific status bits to the interrupt controller
    *
    *******************************************************************************/
    void STL_SetTxInterruptMode(uint8 intSrc) 
    {
        STL_TXSTATUS_MASK_REG = intSrc;
    }


    /*******************************************************************************
    * Function Name: STL_WriteTxData
    ********************************************************************************
    *
    * Summary:
    *  Places a byte of data into the transmit buffer to be sent when the bus is
    *  available without checking the TX status register. You must check status
    *  separately.
    *
    * Parameters:
    *  txDataByte: data byte
    *
    * Return:
    * None.
    *
    * Global Variables:
    *  STL_txBuffer - RAM buffer pointer for save data for transmission
    *  STL_txBufferWrite - cyclic index for write to txBuffer,
    *    incremented after each byte saved to buffer.
    *  STL_txBufferRead - cyclic index for read from txBuffer,
    *    checked to identify the condition to write to FIFO directly or to TX buffer
    *  STL_initVar - checked to identify that the component has been
    *    initialized.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void STL_WriteTxData(uint8 txDataByte) 
    {
        /* If not Initialized then skip this function*/
        if(STL_initVar != 0u)
        {
        #if (STL_TX_INTERRUPT_ENABLED)

            /* Protect variables that could change on interrupt. */
            STL_DisableTxInt();

            if( (STL_txBufferRead == STL_txBufferWrite) &&
                ((STL_TXSTATUS_REG & STL_TX_STS_FIFO_FULL) == 0u) )
            {
                /* Add directly to the FIFO. */
                STL_TXDATA_REG = txDataByte;
            }
            else
            {
                if(STL_txBufferWrite >= STL_TX_BUFFER_SIZE)
                {
                    STL_txBufferWrite = 0u;
                }

                STL_txBuffer[STL_txBufferWrite] = txDataByte;

                /* Add to the software buffer. */
                STL_txBufferWrite++;
            }

            STL_EnableTxInt();

        #else

            /* Add directly to the FIFO. */
            STL_TXDATA_REG = txDataByte;

        #endif /*(STL_TX_INTERRUPT_ENABLED) */
        }
    }


    /*******************************************************************************
    * Function Name: STL_ReadTxStatus
    ********************************************************************************
    *
    * Summary:
    *  Reads the status register for the TX portion of the UART.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Contents of the status register
    *
    * Theory:
    *  This function reads the TX status register, which is cleared on read.
    *  It is up to the user to handle all bits in this return value accordingly,
    *  even if the bit was not enabled as an interrupt source the event happened
    *  and must be handled accordingly.
    *
    *******************************************************************************/
    uint8 STL_ReadTxStatus(void) 
    {
        return(STL_TXSTATUS_REG);
    }


    /*******************************************************************************
    * Function Name: STL_PutChar
    ********************************************************************************
    *
    * Summary:
    *  Puts a byte of data into the transmit buffer to be sent when the bus is
    *  available. This is a blocking API that waits until the TX buffer has room to
    *  hold the data.
    *
    * Parameters:
    *  txDataByte: Byte containing the data to transmit
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  STL_txBuffer - RAM buffer pointer for save data for transmission
    *  STL_txBufferWrite - cyclic index for write to txBuffer,
    *     checked to identify free space in txBuffer and incremented after each byte
    *     saved to buffer.
    *  STL_txBufferRead - cyclic index for read from txBuffer,
    *     checked to identify free space in txBuffer.
    *  STL_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to transmit any byte of data in a single transfer
    *
    *******************************************************************************/
    void STL_PutChar(uint8 txDataByte) 
    {
    #if (STL_TX_INTERRUPT_ENABLED)
        /* The temporary output pointer is used since it takes two instructions
        *  to increment with a wrap, and we can't risk doing that with the real
        *  pointer and getting an interrupt in between instructions.
        */
        uint8 locTxBufferWrite;
        uint8 locTxBufferRead;

        do
        { /* Block if software buffer is full, so we don't overwrite. */

        #if ((STL_TX_BUFFER_SIZE > STL_MAX_BYTE_VALUE) && (CY_PSOC3))
            /* Disable TX interrupt to protect variables from modification */
            STL_DisableTxInt();
        #endif /* (STL_TX_BUFFER_SIZE > STL_MAX_BYTE_VALUE) && (CY_PSOC3) */

            locTxBufferWrite = STL_txBufferWrite;
            locTxBufferRead  = STL_txBufferRead;

        #if ((STL_TX_BUFFER_SIZE > STL_MAX_BYTE_VALUE) && (CY_PSOC3))
            /* Enable interrupt to continue transmission */
            STL_EnableTxInt();
        #endif /* (STL_TX_BUFFER_SIZE > STL_MAX_BYTE_VALUE) && (CY_PSOC3) */
        }
        while( (locTxBufferWrite < locTxBufferRead) ? (locTxBufferWrite == (locTxBufferRead - 1u)) :
                                ((locTxBufferWrite - locTxBufferRead) ==
                                (uint8)(STL_TX_BUFFER_SIZE - 1u)) );

        if( (locTxBufferRead == locTxBufferWrite) &&
            ((STL_TXSTATUS_REG & STL_TX_STS_FIFO_FULL) == 0u) )
        {
            /* Add directly to the FIFO */
            STL_TXDATA_REG = txDataByte;
        }
        else
        {
            if(locTxBufferWrite >= STL_TX_BUFFER_SIZE)
            {
                locTxBufferWrite = 0u;
            }
            /* Add to the software buffer. */
            STL_txBuffer[locTxBufferWrite] = txDataByte;
            locTxBufferWrite++;

            /* Finally, update the real output pointer */
        #if ((STL_TX_BUFFER_SIZE > STL_MAX_BYTE_VALUE) && (CY_PSOC3))
            STL_DisableTxInt();
        #endif /* (STL_TX_BUFFER_SIZE > STL_MAX_BYTE_VALUE) && (CY_PSOC3) */

            STL_txBufferWrite = locTxBufferWrite;

        #if ((STL_TX_BUFFER_SIZE > STL_MAX_BYTE_VALUE) && (CY_PSOC3))
            STL_EnableTxInt();
        #endif /* (STL_TX_BUFFER_SIZE > STL_MAX_BYTE_VALUE) && (CY_PSOC3) */

            if(0u != (STL_TXSTATUS_REG & STL_TX_STS_FIFO_EMPTY))
            {
                /* Trigger TX interrupt to send software buffer */
                STL_SetPendingTxInt();
            }
        }

    #else

        while((STL_TXSTATUS_REG & STL_TX_STS_FIFO_FULL) != 0u)
        {
            /* Wait for room in the FIFO */
        }

        /* Add directly to the FIFO */
        STL_TXDATA_REG = txDataByte;

    #endif /* STL_TX_INTERRUPT_ENABLED */
    }


    /*******************************************************************************
    * Function Name: STL_PutString
    ********************************************************************************
    *
    * Summary:
    *  Sends a NULL terminated string to the TX buffer for transmission.
    *
    * Parameters:
    *  string[]: Pointer to the null terminated string array residing in RAM or ROM
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  STL_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  If there is not enough memory in the TX buffer for the entire string, this
    *  function blocks until the last character of the string is loaded into the
    *  TX buffer.
    *
    *******************************************************************************/
    void STL_PutString(const char8 string[]) 
    {
        uint16 bufIndex = 0u;

        /* If not Initialized then skip this function */
        if(STL_initVar != 0u)
        {
            /* This is a blocking function, it will not exit until all data is sent */
            while(string[bufIndex] != (char8) 0)
            {
                STL_PutChar((uint8)string[bufIndex]);
                bufIndex++;
            }
        }
    }


    /*******************************************************************************
    * Function Name: STL_PutArray
    ********************************************************************************
    *
    * Summary:
    *  Places N bytes of data from a memory array into the TX buffer for
    *  transmission.
    *
    * Parameters:
    *  string[]: Address of the memory array residing in RAM or ROM.
    *  byteCount: Number of bytes to be transmitted. The type depends on TX Buffer
    *             Size parameter.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  STL_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  If there is not enough memory in the TX buffer for the entire string, this
    *  function blocks until the last character of the string is loaded into the
    *  TX buffer.
    *
    *******************************************************************************/
    void STL_PutArray(const uint8 string[], uint8 byteCount)
                                                                    
    {
        uint8 bufIndex = 0u;

        /* If not Initialized then skip this function */
        if(STL_initVar != 0u)
        {
            while(bufIndex < byteCount)
            {
                STL_PutChar(string[bufIndex]);
                bufIndex++;
            }
        }
    }


    /*******************************************************************************
    * Function Name: STL_PutCRLF
    ********************************************************************************
    *
    * Summary:
    *  Writes a byte of data followed by a carriage return (0x0D) and line feed
    *  (0x0A) to the transmit buffer.
    *
    * Parameters:
    *  txDataByte: Data byte to transmit before the carriage return and line feed.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  STL_initVar - checked to identify that the component has been
    *     initialized.
    *
    * Reentrant:
    *  No.
    *
    *******************************************************************************/
    void STL_PutCRLF(uint8 txDataByte) 
    {
        /* If not Initialized then skip this function */
        if(STL_initVar != 0u)
        {
            STL_PutChar(txDataByte);
            STL_PutChar(0x0Du);
            STL_PutChar(0x0Au);
        }
    }


    /*******************************************************************************
    * Function Name: STL_GetTxBufferSize
    ********************************************************************************
    *
    * Summary:
    *  Returns the number of bytes in the TX buffer which are waiting to be 
    *  transmitted.
    *  * TX software buffer is disabled (TX Buffer Size parameter is equal to 4): 
    *    returns 0 for empty TX FIFO, 1 for not full TX FIFO or 4 for full TX FIFO.
    *  * TX software buffer is enabled: returns the number of bytes in the TX 
    *    software buffer which are waiting to be transmitted. Bytes available in the
    *    TX FIFO do not count.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  Number of bytes used in the TX buffer. Return value type depends on the TX 
    *  Buffer Size parameter.
    *
    * Global Variables:
    *  STL_txBufferWrite - used to calculate left space.
    *  STL_txBufferRead - used to calculate left space.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Allows the user to find out how full the TX Buffer is.
    *
    *******************************************************************************/
    uint8 STL_GetTxBufferSize(void)
                                                            
    {
        uint8 size;

    #if (STL_TX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        STL_DisableTxInt();

        if(STL_txBufferRead == STL_txBufferWrite)
        {
            size = 0u;
        }
        else if(STL_txBufferRead < STL_txBufferWrite)
        {
            size = (STL_txBufferWrite - STL_txBufferRead);
        }
        else
        {
            size = (STL_TX_BUFFER_SIZE - STL_txBufferRead) +
                    STL_txBufferWrite;
        }

        STL_EnableTxInt();

    #else

        size = STL_TXSTATUS_REG;

        /* Is the fifo is full. */
        if((size & STL_TX_STS_FIFO_FULL) != 0u)
        {
            size = STL_FIFO_LENGTH;
        }
        else if((size & STL_TX_STS_FIFO_EMPTY) != 0u)
        {
            size = 0u;
        }
        else
        {
            /* We only know there is data in the fifo. */
            size = 1u;
        }

    #endif /* (STL_TX_INTERRUPT_ENABLED) */

    return(size);
    }


    /*******************************************************************************
    * Function Name: STL_ClearTxBuffer
    ********************************************************************************
    *
    * Summary:
    *  Clears all data from the TX buffer and hardware TX FIFO.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  STL_txBufferWrite - cleared to zero.
    *  STL_txBufferRead - cleared to zero.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  Setting the pointers to zero makes the system believe there is no data to
    *  read and writing will resume at address 0 overwriting any data that may have
    *  remained in the RAM.
    *
    * Side Effects:
    *  Data waiting in the transmit buffer is not sent; a byte that is currently
    *  transmitting finishes transmitting.
    *
    *******************************************************************************/
    void STL_ClearTxBuffer(void) 
    {
        uint8 enableInterrupts;

        enableInterrupts = CyEnterCriticalSection();
        /* Clear the HW FIFO */
        STL_TXDATA_AUX_CTL_REG |= (uint8)  STL_TX_FIFO_CLR;
        STL_TXDATA_AUX_CTL_REG &= (uint8) ~STL_TX_FIFO_CLR;
        CyExitCriticalSection(enableInterrupts);

    #if (STL_TX_INTERRUPT_ENABLED)

        /* Protect variables that could change on interrupt. */
        STL_DisableTxInt();

        STL_txBufferRead = 0u;
        STL_txBufferWrite = 0u;

        /* Enable Tx interrupt. */
        STL_EnableTxInt();

    #endif /* (STL_TX_INTERRUPT_ENABLED) */
    }


    /*******************************************************************************
    * Function Name: STL_SendBreak
    ********************************************************************************
    *
    * Summary:
    *  Transmits a break signal on the bus.
    *
    * Parameters:
    *  uint8 retMode:  Send Break return mode. See the following table for options.
    *   STL_SEND_BREAK - Initialize registers for break, send the Break
    *       signal and return immediately.
    *   STL_WAIT_FOR_COMPLETE_REINIT - Wait until break transmission is
    *       complete, reinitialize registers to normal transmission mode then return
    *   STL_REINIT - Reinitialize registers to normal transmission mode
    *       then return.
    *   STL_SEND_WAIT_REINIT - Performs both options: 
    *      STL_SEND_BREAK and STL_WAIT_FOR_COMPLETE_REINIT.
    *      This option is recommended for most cases.
    *
    * Return:
    *  None.
    *
    * Global Variables:
    *  STL_initVar - checked to identify that the component has been
    *     initialized.
    *  txPeriod - static variable, used for keeping TX period configuration.
    *
    * Reentrant:
    *  No.
    *
    * Theory:
    *  SendBreak function initializes registers to send 13-bit break signal. It is
    *  important to return the registers configuration to normal for continue 8-bit
    *  operation.
    *  There are 3 variants for this API usage:
    *  1) SendBreak(3) - function will send the Break signal and take care on the
    *     configuration returning. Function will block CPU until transmission
    *     complete.
    *  2) User may want to use blocking time if UART configured to the low speed
    *     operation
    *     Example for this case:
    *     SendBreak(0);     - initialize Break signal transmission
    *         Add your code here to use CPU time
    *     SendBreak(1);     - complete Break operation
    *  3) Same to 2) but user may want to initialize and use the interrupt to
    *     complete break operation.
    *     Example for this case:
    *     Initialize TX interrupt with "TX - On TX Complete" parameter
    *     SendBreak(0);     - initialize Break signal transmission
    *         Add your code here to use CPU time
    *     When interrupt appear with STL_TX_STS_COMPLETE status:
    *     SendBreak(2);     - complete Break operation
    *
    * Side Effects:
    *  The STL_SendBreak() function initializes registers to send a
    *  break signal.
    *  Break signal length depends on the break signal bits configuration.
    *  The register configuration should be reinitialized before normal 8-bit
    *  communication can continue.
    *
    *******************************************************************************/
    void STL_SendBreak(uint8 retMode) 
    {

        /* If not Initialized then skip this function*/
        if(STL_initVar != 0u)
        {
            /* Set the Counter to 13-bits and transmit a 00 byte */
            /* When that is done then reset the counter value back */
            uint8 tmpStat;

        #if(STL_HD_ENABLED) /* Half Duplex mode*/

            if( (retMode == STL_SEND_BREAK) ||
                (retMode == STL_SEND_WAIT_REINIT ) )
            {
                /* CTRL_HD_SEND_BREAK - sends break bits in HD mode */
                STL_WriteControlRegister(STL_ReadControlRegister() |
                                                      STL_CTRL_HD_SEND_BREAK);
                /* Send zeros */
                STL_TXDATA_REG = 0u;

                do /* Wait until transmit starts */
                {
                    tmpStat = STL_TXSTATUS_REG;
                }
                while((tmpStat & STL_TX_STS_FIFO_EMPTY) != 0u);
            }

            if( (retMode == STL_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == STL_SEND_WAIT_REINIT) )
            {
                do /* Wait until transmit complete */
                {
                    tmpStat = STL_TXSTATUS_REG;
                }
                while(((uint8)~tmpStat & STL_TX_STS_COMPLETE) != 0u);
            }

            if( (retMode == STL_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == STL_REINIT) ||
                (retMode == STL_SEND_WAIT_REINIT) )
            {
                STL_WriteControlRegister(STL_ReadControlRegister() &
                                              (uint8)~STL_CTRL_HD_SEND_BREAK);
            }

        #else /* STL_HD_ENABLED Full Duplex mode */

            static uint8 txPeriod;

            if( (retMode == STL_SEND_BREAK) ||
                (retMode == STL_SEND_WAIT_REINIT) )
            {
                /* CTRL_HD_SEND_BREAK - skip to send parity bit at Break signal in Full Duplex mode */
                #if( (STL_PARITY_TYPE != STL__B_UART__NONE_REVB) || \
                                    (STL_PARITY_TYPE_SW != 0u) )
                    STL_WriteControlRegister(STL_ReadControlRegister() |
                                                          STL_CTRL_HD_SEND_BREAK);
                #endif /* End STL_PARITY_TYPE != STL__B_UART__NONE_REVB  */

                #if(STL_TXCLKGEN_DP)
                    txPeriod = STL_TXBITCLKTX_COMPLETE_REG;
                    STL_TXBITCLKTX_COMPLETE_REG = STL_TXBITCTR_BREAKBITS;
                #else
                    txPeriod = STL_TXBITCTR_PERIOD_REG;
                    STL_TXBITCTR_PERIOD_REG = STL_TXBITCTR_BREAKBITS8X;
                #endif /* End STL_TXCLKGEN_DP */

                /* Send zeros */
                STL_TXDATA_REG = 0u;

                do /* Wait until transmit starts */
                {
                    tmpStat = STL_TXSTATUS_REG;
                }
                while((tmpStat & STL_TX_STS_FIFO_EMPTY) != 0u);
            }

            if( (retMode == STL_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == STL_SEND_WAIT_REINIT) )
            {
                do /* Wait until transmit complete */
                {
                    tmpStat = STL_TXSTATUS_REG;
                }
                while(((uint8)~tmpStat & STL_TX_STS_COMPLETE) != 0u);
            }

            if( (retMode == STL_WAIT_FOR_COMPLETE_REINIT) ||
                (retMode == STL_REINIT) ||
                (retMode == STL_SEND_WAIT_REINIT) )
            {

            #if(STL_TXCLKGEN_DP)
                STL_TXBITCLKTX_COMPLETE_REG = txPeriod;
            #else
                STL_TXBITCTR_PERIOD_REG = txPeriod;
            #endif /* End STL_TXCLKGEN_DP */

            #if( (STL_PARITY_TYPE != STL__B_UART__NONE_REVB) || \
                 (STL_PARITY_TYPE_SW != 0u) )
                STL_WriteControlRegister(STL_ReadControlRegister() &
                                                      (uint8) ~STL_CTRL_HD_SEND_BREAK);
            #endif /* End STL_PARITY_TYPE != NONE */
            }
        #endif    /* End STL_HD_ENABLED */
        }
    }


    /*******************************************************************************
    * Function Name: STL_SetTxAddressMode
    ********************************************************************************
    *
    * Summary:
    *  Configures the transmitter to signal the next bytes is address or data.
    *
    * Parameters:
    *  addressMode: 
    *       STL_SET_SPACE - Configure the transmitter to send the next
    *                                    byte as a data.
    *       STL_SET_MARK  - Configure the transmitter to send the next
    *                                    byte as an address.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  This function sets and clears STL_CTRL_MARK bit in the Control
    *  register.
    *
    *******************************************************************************/
    void STL_SetTxAddressMode(uint8 addressMode) 
    {
        /* Mark/Space sending enable */
        if(addressMode != 0u)
        {
        #if( STL_CONTROL_REG_REMOVED == 0u )
            STL_WriteControlRegister(STL_ReadControlRegister() |
                                                  STL_CTRL_MARK);
        #endif /* End STL_CONTROL_REG_REMOVED == 0u */
        }
        else
        {
        #if( STL_CONTROL_REG_REMOVED == 0u )
            STL_WriteControlRegister(STL_ReadControlRegister() &
                                                  (uint8) ~STL_CTRL_MARK);
        #endif /* End STL_CONTROL_REG_REMOVED == 0u */
        }
    }

#endif  /* EndSTL_TX_ENABLED */

#if(STL_HD_ENABLED)


    /*******************************************************************************
    * Function Name: STL_LoadRxConfig
    ********************************************************************************
    *
    * Summary:
    *  Loads the receiver configuration in half duplex mode. After calling this
    *  function, the UART is ready to receive data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  Valid only in half duplex mode. You must make sure that the previous
    *  transaction is complete and it is safe to unload the transmitter
    *  configuration.
    *
    *******************************************************************************/
    void STL_LoadRxConfig(void) 
    {
        STL_WriteControlRegister(STL_ReadControlRegister() &
                                                (uint8)~STL_CTRL_HD_SEND);
        STL_RXBITCTR_PERIOD_REG = STL_HD_RXBITCTR_INIT;

    #if (STL_RX_INTERRUPT_ENABLED)
        /* Enable RX interrupt after set RX configuration */
        STL_SetRxInterruptMode(STL_INIT_RX_INTERRUPTS_MASK);
    #endif /* (STL_RX_INTERRUPT_ENABLED) */
    }


    /*******************************************************************************
    * Function Name: STL_LoadTxConfig
    ********************************************************************************
    *
    * Summary:
    *  Loads the transmitter configuration in half duplex mode. After calling this
    *  function, the UART is ready to transmit data.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    * Side Effects:
    *  Valid only in half duplex mode. You must make sure that the previous
    *  transaction is complete and it is safe to unload the receiver configuration.
    *
    *******************************************************************************/
    void STL_LoadTxConfig(void) 
    {
    #if (STL_RX_INTERRUPT_ENABLED)
        /* Disable RX interrupts before set TX configuration */
        STL_SetRxInterruptMode(0u);
    #endif /* (STL_RX_INTERRUPT_ENABLED) */

        STL_WriteControlRegister(STL_ReadControlRegister() | STL_CTRL_HD_SEND);
        STL_RXBITCTR_PERIOD_REG = STL_HD_TXBITCTR_INIT;
    }

#endif  /* STL_HD_ENABLED */


/* [] END OF FILE */
