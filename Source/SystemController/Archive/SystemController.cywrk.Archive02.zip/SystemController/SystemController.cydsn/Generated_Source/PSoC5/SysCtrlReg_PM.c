/*******************************************************************************
* File Name: SysCtrlReg_PM.c
* Version 1.80
*
* Description:
*  This file contains the setup, control, and status commands to support 
*  the component operation in the low power mode. 
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "SysCtrlReg.h"

/* Check for removal by optimization */
#if !defined(SysCtrlReg_Sync_ctrl_reg__REMOVED)

static SysCtrlReg_BACKUP_STRUCT  SysCtrlReg_backup = {0u};

    
/*******************************************************************************
* Function Name: SysCtrlReg_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SysCtrlReg_SaveConfig(void) 
{
    SysCtrlReg_backup.controlState = SysCtrlReg_Control;
}


/*******************************************************************************
* Function Name: SysCtrlReg_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*
*******************************************************************************/
void SysCtrlReg_RestoreConfig(void) 
{
     SysCtrlReg_Control = SysCtrlReg_backup.controlState;
}


/*******************************************************************************
* Function Name: SysCtrlReg_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component for entering the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SysCtrlReg_Sleep(void) 
{
    SysCtrlReg_SaveConfig();
}


/*******************************************************************************
* Function Name: SysCtrlReg_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component after waking up from the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SysCtrlReg_Wakeup(void)  
{
    SysCtrlReg_RestoreConfig();
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
