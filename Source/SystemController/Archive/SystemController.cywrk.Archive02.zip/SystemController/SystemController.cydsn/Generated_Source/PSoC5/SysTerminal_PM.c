/*******************************************************************************
* File Name: SysTerminal_PM.c
* Version 2.50
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SysTerminal.h"


/***************************************
* Local data allocation
***************************************/

static SysTerminal_BACKUP_STRUCT  SysTerminal_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: SysTerminal_SaveConfig
********************************************************************************
*
* Summary:
*  This function saves the component nonretention control register.
*  Does not save the FIFO which is a set of nonretention registers.
*  This function is called by the SysTerminal_Sleep() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SysTerminal_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SysTerminal_SaveConfig(void)
{
    #if(SysTerminal_CONTROL_REG_REMOVED == 0u)
        SysTerminal_backup.cr = SysTerminal_CONTROL_REG;
    #endif /* End SysTerminal_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: SysTerminal_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the nonretention control register except FIFO.
*  Does not restore the FIFO which is a set of nonretention registers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SysTerminal_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
* Notes:
*  If this function is called without calling SysTerminal_SaveConfig() 
*  first, the data loaded may be incorrect.
*
*******************************************************************************/
void SysTerminal_RestoreConfig(void)
{
    #if(SysTerminal_CONTROL_REG_REMOVED == 0u)
        SysTerminal_CONTROL_REG = SysTerminal_backup.cr;
    #endif /* End SysTerminal_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: SysTerminal_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred API to prepare the component for sleep. 
*  The SysTerminal_Sleep() API saves the current component state. Then it
*  calls the SysTerminal_Stop() function and calls 
*  SysTerminal_SaveConfig() to save the hardware configuration.
*  Call the SysTerminal_Sleep() function before calling the CyPmSleep() 
*  or the CyPmHibernate() function. 
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SysTerminal_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SysTerminal_Sleep(void)
{
    #if(SysTerminal_RX_ENABLED || SysTerminal_HD_ENABLED)
        if((SysTerminal_RXSTATUS_ACTL_REG  & SysTerminal_INT_ENABLE) != 0u)
        {
            SysTerminal_backup.enableState = 1u;
        }
        else
        {
            SysTerminal_backup.enableState = 0u;
        }
    #else
        if((SysTerminal_TXSTATUS_ACTL_REG  & SysTerminal_INT_ENABLE) !=0u)
        {
            SysTerminal_backup.enableState = 1u;
        }
        else
        {
            SysTerminal_backup.enableState = 0u;
        }
    #endif /* End SysTerminal_RX_ENABLED || SysTerminal_HD_ENABLED*/

    SysTerminal_Stop();
    SysTerminal_SaveConfig();
}


/*******************************************************************************
* Function Name: SysTerminal_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred API to restore the component to the state when 
*  SysTerminal_Sleep() was called. The SysTerminal_Wakeup() function
*  calls the SysTerminal_RestoreConfig() function to restore the 
*  configuration. If the component was enabled before the 
*  SysTerminal_Sleep() function was called, the SysTerminal_Wakeup()
*  function will also re-enable the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  SysTerminal_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void SysTerminal_Wakeup(void)
{
    SysTerminal_RestoreConfig();
    #if( (SysTerminal_RX_ENABLED) || (SysTerminal_HD_ENABLED) )
        SysTerminal_ClearRxBuffer();
    #endif /* End (SysTerminal_RX_ENABLED) || (SysTerminal_HD_ENABLED) */
    #if(SysTerminal_TX_ENABLED || SysTerminal_HD_ENABLED)
        SysTerminal_ClearTxBuffer();
    #endif /* End SysTerminal_TX_ENABLED || SysTerminal_HD_ENABLED */

    if(SysTerminal_backup.enableState != 0u)
    {
        SysTerminal_Enable();
    }
}


/* [] END OF FILE */
