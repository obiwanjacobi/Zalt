/*******************************************************************************
* File Name: Z80Controller_RegA.h  
* Version 1.90
*
* Description:
*  This file containts Status Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_STATUS_REG_Z80Controller_RegA_H) /* CY_STATUS_REG_Z80Controller_RegA_H */
#define CY_STATUS_REG_Z80Controller_RegA_H

#include "cytypes.h"
#include "CyLib.h"

    
/***************************************
*     Data Struct Definitions
***************************************/

/* Sleep Mode API Support */
typedef struct
{
    uint8 statusState;

} Z80Controller_RegA_BACKUP_STRUCT;


/***************************************
*        Function Prototypes
***************************************/

uint8 Z80Controller_RegA_Read(void) ;
void Z80Controller_RegA_InterruptEnable(void) ;
void Z80Controller_RegA_InterruptDisable(void) ;
void Z80Controller_RegA_WriteMask(uint8 mask) ;
uint8 Z80Controller_RegA_ReadMask(void) ;


/***************************************
*           API Constants
***************************************/

#define Z80Controller_RegA_STATUS_INTR_ENBL    0x10u


/***************************************
*         Parameter Constants
***************************************/

/* Status Register Inputs */
#define Z80Controller_RegA_INPUTS              8


/***************************************
*             Registers
***************************************/

/* Status Register */
#define Z80Controller_RegA_Status             (* (reg8 *) Z80Controller_RegA_sts_sts_reg__STATUS_REG )
#define Z80Controller_RegA_Status_PTR         (  (reg8 *) Z80Controller_RegA_sts_sts_reg__STATUS_REG )
#define Z80Controller_RegA_Status_Mask        (* (reg8 *) Z80Controller_RegA_sts_sts_reg__MASK_REG )
#define Z80Controller_RegA_Status_Aux_Ctrl    (* (reg8 *) Z80Controller_RegA_sts_sts_reg__STATUS_AUX_CTL_REG )

#endif /* End CY_STATUS_REG_Z80Controller_RegA_H */


/* [] END OF FILE */
