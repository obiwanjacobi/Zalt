/*******************************************************************************
* File Name: LsbA.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LsbA_H) /* Pins LsbA_H */
#define CY_PINS_LsbA_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "LsbA_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 LsbA__PORT == 15 && ((LsbA__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    LsbA_Write(uint8 value);
void    LsbA_SetDriveMode(uint8 mode);
uint8   LsbA_ReadDataReg(void);
uint8   LsbA_Read(void);
void    LsbA_SetInterruptMode(uint16 position, uint16 mode);
uint8   LsbA_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the LsbA_SetDriveMode() function.
     *  @{
     */
        #define LsbA_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define LsbA_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define LsbA_DM_RES_UP          PIN_DM_RES_UP
        #define LsbA_DM_RES_DWN         PIN_DM_RES_DWN
        #define LsbA_DM_OD_LO           PIN_DM_OD_LO
        #define LsbA_DM_OD_HI           PIN_DM_OD_HI
        #define LsbA_DM_STRONG          PIN_DM_STRONG
        #define LsbA_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define LsbA_MASK               LsbA__MASK
#define LsbA_SHIFT              LsbA__SHIFT
#define LsbA_WIDTH              8u

/* Interrupt constants */
#if defined(LsbA__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in LsbA_SetInterruptMode() function.
     *  @{
     */
        #define LsbA_INTR_NONE      (uint16)(0x0000u)
        #define LsbA_INTR_RISING    (uint16)(0x0001u)
        #define LsbA_INTR_FALLING   (uint16)(0x0002u)
        #define LsbA_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define LsbA_INTR_MASK      (0x01u) 
#endif /* (LsbA__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define LsbA_PS                     (* (reg8 *) LsbA__PS)
/* Data Register */
#define LsbA_DR                     (* (reg8 *) LsbA__DR)
/* Port Number */
#define LsbA_PRT_NUM                (* (reg8 *) LsbA__PRT) 
/* Connect to Analog Globals */                                                  
#define LsbA_AG                     (* (reg8 *) LsbA__AG)                       
/* Analog MUX bux enable */
#define LsbA_AMUX                   (* (reg8 *) LsbA__AMUX) 
/* Bidirectional Enable */                                                        
#define LsbA_BIE                    (* (reg8 *) LsbA__BIE)
/* Bit-mask for Aliased Register Access */
#define LsbA_BIT_MASK               (* (reg8 *) LsbA__BIT_MASK)
/* Bypass Enable */
#define LsbA_BYP                    (* (reg8 *) LsbA__BYP)
/* Port wide control signals */                                                   
#define LsbA_CTL                    (* (reg8 *) LsbA__CTL)
/* Drive Modes */
#define LsbA_DM0                    (* (reg8 *) LsbA__DM0) 
#define LsbA_DM1                    (* (reg8 *) LsbA__DM1)
#define LsbA_DM2                    (* (reg8 *) LsbA__DM2) 
/* Input Buffer Disable Override */
#define LsbA_INP_DIS                (* (reg8 *) LsbA__INP_DIS)
/* LCD Common or Segment Drive */
#define LsbA_LCD_COM_SEG            (* (reg8 *) LsbA__LCD_COM_SEG)
/* Enable Segment LCD */
#define LsbA_LCD_EN                 (* (reg8 *) LsbA__LCD_EN)
/* Slew Rate Control */
#define LsbA_SLW                    (* (reg8 *) LsbA__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define LsbA_PRTDSI__CAPS_SEL       (* (reg8 *) LsbA__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define LsbA_PRTDSI__DBL_SYNC_IN    (* (reg8 *) LsbA__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define LsbA_PRTDSI__OE_SEL0        (* (reg8 *) LsbA__PRTDSI__OE_SEL0) 
#define LsbA_PRTDSI__OE_SEL1        (* (reg8 *) LsbA__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define LsbA_PRTDSI__OUT_SEL0       (* (reg8 *) LsbA__PRTDSI__OUT_SEL0) 
#define LsbA_PRTDSI__OUT_SEL1       (* (reg8 *) LsbA__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define LsbA_PRTDSI__SYNC_OUT       (* (reg8 *) LsbA__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(LsbA__SIO_CFG)
    #define LsbA_SIO_HYST_EN        (* (reg8 *) LsbA__SIO_HYST_EN)
    #define LsbA_SIO_REG_HIFREQ     (* (reg8 *) LsbA__SIO_REG_HIFREQ)
    #define LsbA_SIO_CFG            (* (reg8 *) LsbA__SIO_CFG)
    #define LsbA_SIO_DIFF           (* (reg8 *) LsbA__SIO_DIFF)
#endif /* (LsbA__SIO_CFG) */

/* Interrupt Registers */
#if defined(LsbA__INTSTAT)
    #define LsbA_INTSTAT            (* (reg8 *) LsbA__INTSTAT)
    #define LsbA_SNAP               (* (reg8 *) LsbA__SNAP)
    
	#define LsbA_0_INTTYPE_REG 		(* (reg8 *) LsbA__0__INTTYPE)
	#define LsbA_1_INTTYPE_REG 		(* (reg8 *) LsbA__1__INTTYPE)
	#define LsbA_2_INTTYPE_REG 		(* (reg8 *) LsbA__2__INTTYPE)
	#define LsbA_3_INTTYPE_REG 		(* (reg8 *) LsbA__3__INTTYPE)
	#define LsbA_4_INTTYPE_REG 		(* (reg8 *) LsbA__4__INTTYPE)
	#define LsbA_5_INTTYPE_REG 		(* (reg8 *) LsbA__5__INTTYPE)
	#define LsbA_6_INTTYPE_REG 		(* (reg8 *) LsbA__6__INTTYPE)
	#define LsbA_7_INTTYPE_REG 		(* (reg8 *) LsbA__7__INTTYPE)
#endif /* (LsbA__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_LsbA_H */


/* [] END OF FILE */
