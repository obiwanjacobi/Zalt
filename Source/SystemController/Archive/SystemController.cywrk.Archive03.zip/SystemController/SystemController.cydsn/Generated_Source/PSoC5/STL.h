/*******************************************************************************
* File Name: STL.h
* Version 2.50
*
* Description:
*  Contains the function prototypes and constants available to the UART
*  user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/


#if !defined(CY_UART_STL_H)
#define CY_UART_STL_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h"


/***************************************
* Conditional Compilation Parameters
***************************************/

#define STL_RX_ENABLED                     (1u)
#define STL_TX_ENABLED                     (1u)
#define STL_HD_ENABLED                     (0u)
#define STL_RX_INTERRUPT_ENABLED           (0u)
#define STL_TX_INTERRUPT_ENABLED           (0u)
#define STL_INTERNAL_CLOCK_USED            (1u)
#define STL_RXHW_ADDRESS_ENABLED           (0u)
#define STL_OVER_SAMPLE_COUNT              (8u)
#define STL_PARITY_TYPE                    (0u)
#define STL_PARITY_TYPE_SW                 (0u)
#define STL_BREAK_DETECT                   (0u)
#define STL_BREAK_BITS_TX                  (13u)
#define STL_BREAK_BITS_RX                  (13u)
#define STL_TXCLKGEN_DP                    (1u)
#define STL_USE23POLLING                   (1u)
#define STL_FLOW_CONTROL                   (0u)
#define STL_CLK_FREQ                       (0u)
#define STL_TX_BUFFER_SIZE                 (4u)
#define STL_RX_BUFFER_SIZE                 (4u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component UART_v2_50 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */

#if defined(STL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG)
    #define STL_CONTROL_REG_REMOVED            (0u)
#else
    #define STL_CONTROL_REG_REMOVED            (1u)
#endif /* End STL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */


/***************************************
*      Data Structure Definition
***************************************/

/* Sleep Mode API Support */
typedef struct STL_backupStruct_
{
    uint8 enableState;

    #if(STL_CONTROL_REG_REMOVED == 0u)
        uint8 cr;
    #endif /* End STL_CONTROL_REG_REMOVED */

} STL_BACKUP_STRUCT;


/***************************************
*       Function Prototypes
***************************************/

void STL_Start(void) ;
void STL_Stop(void) ;
uint8 STL_ReadControlRegister(void) ;
void STL_WriteControlRegister(uint8 control) ;

void STL_Init(void) ;
void STL_Enable(void) ;
void STL_SaveConfig(void) ;
void STL_RestoreConfig(void) ;
void STL_Sleep(void) ;
void STL_Wakeup(void) ;

/* Only if RX is enabled */
#if( (STL_RX_ENABLED) || (STL_HD_ENABLED) )

    #if (STL_RX_INTERRUPT_ENABLED)
        #define STL_EnableRxInt()  CyIntEnable (STL_RX_VECT_NUM)
        #define STL_DisableRxInt() CyIntDisable(STL_RX_VECT_NUM)
        CY_ISR_PROTO(STL_RXISR);
    #endif /* STL_RX_INTERRUPT_ENABLED */

    void STL_SetRxAddressMode(uint8 addressMode)
                                                           ;
    void STL_SetRxAddress1(uint8 address) ;
    void STL_SetRxAddress2(uint8 address) ;

    void  STL_SetRxInterruptMode(uint8 intSrc) ;
    uint8 STL_ReadRxData(void) ;
    uint8 STL_ReadRxStatus(void) ;
    uint8 STL_GetChar(void) ;
    uint16 STL_GetByte(void) ;
    uint8 STL_GetRxBufferSize(void)
                                                            ;
    void STL_ClearRxBuffer(void) ;

    /* Obsolete functions, defines for backward compatible */
    #define STL_GetRxInterruptSource   STL_ReadRxStatus

#endif /* End (STL_RX_ENABLED) || (STL_HD_ENABLED) */

/* Only if TX is enabled */
#if(STL_TX_ENABLED || STL_HD_ENABLED)

    #if(STL_TX_INTERRUPT_ENABLED)
        #define STL_EnableTxInt()  CyIntEnable (STL_TX_VECT_NUM)
        #define STL_DisableTxInt() CyIntDisable(STL_TX_VECT_NUM)
        #define STL_SetPendingTxInt() CyIntSetPending(STL_TX_VECT_NUM)
        #define STL_ClearPendingTxInt() CyIntClearPending(STL_TX_VECT_NUM)
        CY_ISR_PROTO(STL_TXISR);
    #endif /* STL_TX_INTERRUPT_ENABLED */

    void STL_SetTxInterruptMode(uint8 intSrc) ;
    void STL_WriteTxData(uint8 txDataByte) ;
    uint8 STL_ReadTxStatus(void) ;
    void STL_PutChar(uint8 txDataByte) ;
    void STL_PutString(const char8 string[]) ;
    void STL_PutArray(const uint8 string[], uint8 byteCount)
                                                            ;
    void STL_PutCRLF(uint8 txDataByte) ;
    void STL_ClearTxBuffer(void) ;
    void STL_SetTxAddressMode(uint8 addressMode) ;
    void STL_SendBreak(uint8 retMode) ;
    uint8 STL_GetTxBufferSize(void)
                                                            ;
    /* Obsolete functions, defines for backward compatible */
    #define STL_PutStringConst         STL_PutString
    #define STL_PutArrayConst          STL_PutArray
    #define STL_GetTxInterruptSource   STL_ReadTxStatus

#endif /* End STL_TX_ENABLED || STL_HD_ENABLED */

#if(STL_HD_ENABLED)
    void STL_LoadRxConfig(void) ;
    void STL_LoadTxConfig(void) ;
#endif /* End STL_HD_ENABLED */


/* Communication bootloader APIs */
#if defined(CYDEV_BOOTLOADER_IO_COMP) && ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_STL) || \
                                          (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))
    /* Physical layer functions */
    void    STL_CyBtldrCommStart(void) CYSMALL ;
    void    STL_CyBtldrCommStop(void) CYSMALL ;
    void    STL_CyBtldrCommReset(void) CYSMALL ;
    cystatus STL_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;
    cystatus STL_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) CYSMALL
             ;

    #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_STL)
        #define CyBtldrCommStart    STL_CyBtldrCommStart
        #define CyBtldrCommStop     STL_CyBtldrCommStop
        #define CyBtldrCommReset    STL_CyBtldrCommReset
        #define CyBtldrCommWrite    STL_CyBtldrCommWrite
        #define CyBtldrCommRead     STL_CyBtldrCommRead
    #endif  /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_STL) */

    /* Byte to Byte time out for detecting end of block data from host */
    #define STL_BYTE2BYTE_TIME_OUT (25u)
    #define STL_PACKET_EOP         (0x17u) /* End of packet defined by bootloader */
    #define STL_WAIT_EOP_DELAY     (5u)    /* Additional 5ms to wait for End of packet */
    #define STL_BL_CHK_DELAY_MS    (1u)    /* Time Out quantity equal 1mS */

#endif /* CYDEV_BOOTLOADER_IO_COMP */


/***************************************
*          API Constants
***************************************/
/* Parameters for SetTxAddressMode API*/
#define STL_SET_SPACE      (0x00u)
#define STL_SET_MARK       (0x01u)

/* Status Register definitions */
#if( (STL_TX_ENABLED) || (STL_HD_ENABLED) )
    #if(STL_TX_INTERRUPT_ENABLED)
        #define STL_TX_VECT_NUM            (uint8)STL_TXInternalInterrupt__INTC_NUMBER
        #define STL_TX_PRIOR_NUM           (uint8)STL_TXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* STL_TX_INTERRUPT_ENABLED */

    #define STL_TX_STS_COMPLETE_SHIFT          (0x00u)
    #define STL_TX_STS_FIFO_EMPTY_SHIFT        (0x01u)
    #define STL_TX_STS_FIFO_NOT_FULL_SHIFT     (0x03u)
    #if(STL_TX_ENABLED)
        #define STL_TX_STS_FIFO_FULL_SHIFT     (0x02u)
    #else /* (STL_HD_ENABLED) */
        #define STL_TX_STS_FIFO_FULL_SHIFT     (0x05u)  /* Needs MD=0 */
    #endif /* (STL_TX_ENABLED) */

    #define STL_TX_STS_COMPLETE            (uint8)(0x01u << STL_TX_STS_COMPLETE_SHIFT)
    #define STL_TX_STS_FIFO_EMPTY          (uint8)(0x01u << STL_TX_STS_FIFO_EMPTY_SHIFT)
    #define STL_TX_STS_FIFO_FULL           (uint8)(0x01u << STL_TX_STS_FIFO_FULL_SHIFT)
    #define STL_TX_STS_FIFO_NOT_FULL       (uint8)(0x01u << STL_TX_STS_FIFO_NOT_FULL_SHIFT)
#endif /* End (STL_TX_ENABLED) || (STL_HD_ENABLED)*/

#if( (STL_RX_ENABLED) || (STL_HD_ENABLED) )
    #if(STL_RX_INTERRUPT_ENABLED)
        #define STL_RX_VECT_NUM            (uint8)STL_RXInternalInterrupt__INTC_NUMBER
        #define STL_RX_PRIOR_NUM           (uint8)STL_RXInternalInterrupt__INTC_PRIOR_NUM
    #endif /* STL_RX_INTERRUPT_ENABLED */
    #define STL_RX_STS_MRKSPC_SHIFT            (0x00u)
    #define STL_RX_STS_BREAK_SHIFT             (0x01u)
    #define STL_RX_STS_PAR_ERROR_SHIFT         (0x02u)
    #define STL_RX_STS_STOP_ERROR_SHIFT        (0x03u)
    #define STL_RX_STS_OVERRUN_SHIFT           (0x04u)
    #define STL_RX_STS_FIFO_NOTEMPTY_SHIFT     (0x05u)
    #define STL_RX_STS_ADDR_MATCH_SHIFT        (0x06u)
    #define STL_RX_STS_SOFT_BUFF_OVER_SHIFT    (0x07u)

    #define STL_RX_STS_MRKSPC           (uint8)(0x01u << STL_RX_STS_MRKSPC_SHIFT)
    #define STL_RX_STS_BREAK            (uint8)(0x01u << STL_RX_STS_BREAK_SHIFT)
    #define STL_RX_STS_PAR_ERROR        (uint8)(0x01u << STL_RX_STS_PAR_ERROR_SHIFT)
    #define STL_RX_STS_STOP_ERROR       (uint8)(0x01u << STL_RX_STS_STOP_ERROR_SHIFT)
    #define STL_RX_STS_OVERRUN          (uint8)(0x01u << STL_RX_STS_OVERRUN_SHIFT)
    #define STL_RX_STS_FIFO_NOTEMPTY    (uint8)(0x01u << STL_RX_STS_FIFO_NOTEMPTY_SHIFT)
    #define STL_RX_STS_ADDR_MATCH       (uint8)(0x01u << STL_RX_STS_ADDR_MATCH_SHIFT)
    #define STL_RX_STS_SOFT_BUFF_OVER   (uint8)(0x01u << STL_RX_STS_SOFT_BUFF_OVER_SHIFT)
    #define STL_RX_HW_MASK                     (0x7Fu)
#endif /* End (STL_RX_ENABLED) || (STL_HD_ENABLED) */

/* Control Register definitions */
#define STL_CTRL_HD_SEND_SHIFT                 (0x00u) /* 1 enable TX part in Half Duplex mode */
#define STL_CTRL_HD_SEND_BREAK_SHIFT           (0x01u) /* 1 send BREAK signal in Half Duplez mode */
#define STL_CTRL_MARK_SHIFT                    (0x02u) /* 1 sets mark, 0 sets space */
#define STL_CTRL_PARITY_TYPE0_SHIFT            (0x03u) /* Defines the type of parity implemented */
#define STL_CTRL_PARITY_TYPE1_SHIFT            (0x04u) /* Defines the type of parity implemented */
#define STL_CTRL_RXADDR_MODE0_SHIFT            (0x05u)
#define STL_CTRL_RXADDR_MODE1_SHIFT            (0x06u)
#define STL_CTRL_RXADDR_MODE2_SHIFT            (0x07u)

#define STL_CTRL_HD_SEND               (uint8)(0x01u << STL_CTRL_HD_SEND_SHIFT)
#define STL_CTRL_HD_SEND_BREAK         (uint8)(0x01u << STL_CTRL_HD_SEND_BREAK_SHIFT)
#define STL_CTRL_MARK                  (uint8)(0x01u << STL_CTRL_MARK_SHIFT)
#define STL_CTRL_PARITY_TYPE_MASK      (uint8)(0x03u << STL_CTRL_PARITY_TYPE0_SHIFT)
#define STL_CTRL_RXADDR_MODE_MASK      (uint8)(0x07u << STL_CTRL_RXADDR_MODE0_SHIFT)

/* StatusI Register Interrupt Enable Control Bits. As defined by the Register map for the AUX Control Register */
#define STL_INT_ENABLE                         (0x10u)

/* Bit Counter (7-bit) Control Register Bit Definitions. As defined by the Register map for the AUX Control Register */
#define STL_CNTR_ENABLE                        (0x20u)

/*   Constants for SendBreak() "retMode" parameter  */
#define STL_SEND_BREAK                         (0x00u)
#define STL_WAIT_FOR_COMPLETE_REINIT           (0x01u)
#define STL_REINIT                             (0x02u)
#define STL_SEND_WAIT_REINIT                   (0x03u)

#define STL_OVER_SAMPLE_8                      (8u)
#define STL_OVER_SAMPLE_16                     (16u)

#define STL_BIT_CENTER                         (STL_OVER_SAMPLE_COUNT - 2u)

#define STL_FIFO_LENGTH                        (4u)
#define STL_NUMBER_OF_START_BIT                (1u)
#define STL_MAX_BYTE_VALUE                     (0xFFu)

/* 8X always for count7 implementation */
#define STL_TXBITCTR_BREAKBITS8X   ((STL_BREAK_BITS_TX * STL_OVER_SAMPLE_8) - 1u)
/* 8X or 16X for DP implementation */
#define STL_TXBITCTR_BREAKBITS ((STL_BREAK_BITS_TX * STL_OVER_SAMPLE_COUNT) - 1u)

#define STL_HALF_BIT_COUNT   \
                            (((STL_OVER_SAMPLE_COUNT / 2u) + (STL_USE23POLLING * 1u)) - 2u)
#if (STL_OVER_SAMPLE_COUNT == STL_OVER_SAMPLE_8)
    #define STL_HD_TXBITCTR_INIT   (((STL_BREAK_BITS_TX + \
                            STL_NUMBER_OF_START_BIT) * STL_OVER_SAMPLE_COUNT) - 1u)

    /* This parameter is increased on the 2 in 2 out of 3 mode to sample voting in the middle */
    #define STL_RXBITCTR_INIT  ((((STL_BREAK_BITS_RX + STL_NUMBER_OF_START_BIT) \
                            * STL_OVER_SAMPLE_COUNT) + STL_HALF_BIT_COUNT) - 1u)

#else /* STL_OVER_SAMPLE_COUNT == STL_OVER_SAMPLE_16 */
    #define STL_HD_TXBITCTR_INIT   ((8u * STL_OVER_SAMPLE_COUNT) - 1u)
    /* 7bit counter need one more bit for OverSampleCount = 16 */
    #define STL_RXBITCTR_INIT      (((7u * STL_OVER_SAMPLE_COUNT) - 1u) + \
                                                      STL_HALF_BIT_COUNT)
#endif /* End STL_OVER_SAMPLE_COUNT */

#define STL_HD_RXBITCTR_INIT                   STL_RXBITCTR_INIT


/***************************************
* Global variables external identifier
***************************************/

extern uint8 STL_initVar;
#if (STL_TX_INTERRUPT_ENABLED && STL_TX_ENABLED)
    extern volatile uint8 STL_txBuffer[STL_TX_BUFFER_SIZE];
    extern volatile uint8 STL_txBufferRead;
    extern uint8 STL_txBufferWrite;
#endif /* (STL_TX_INTERRUPT_ENABLED && STL_TX_ENABLED) */
#if (STL_RX_INTERRUPT_ENABLED && (STL_RX_ENABLED || STL_HD_ENABLED))
    extern uint8 STL_errorStatus;
    extern volatile uint8 STL_rxBuffer[STL_RX_BUFFER_SIZE];
    extern volatile uint8 STL_rxBufferRead;
    extern volatile uint8 STL_rxBufferWrite;
    extern volatile uint8 STL_rxBufferLoopDetect;
    extern volatile uint8 STL_rxBufferOverflow;
    #if (STL_RXHW_ADDRESS_ENABLED)
        extern volatile uint8 STL_rxAddressMode;
        extern volatile uint8 STL_rxAddressDetected;
    #endif /* (STL_RXHW_ADDRESS_ENABLED) */
#endif /* (STL_RX_INTERRUPT_ENABLED && (STL_RX_ENABLED || STL_HD_ENABLED)) */


/***************************************
* Enumerated Types and Parameters
***************************************/

#define STL__B_UART__AM_SW_BYTE_BYTE 1
#define STL__B_UART__AM_SW_DETECT_TO_BUFFER 2
#define STL__B_UART__AM_HW_BYTE_BY_BYTE 3
#define STL__B_UART__AM_HW_DETECT_TO_BUFFER 4
#define STL__B_UART__AM_NONE 0

#define STL__B_UART__NONE_REVB 0
#define STL__B_UART__EVEN_REVB 1
#define STL__B_UART__ODD_REVB 2
#define STL__B_UART__MARK_SPACE_REVB 3



/***************************************
*    Initial Parameter Constants
***************************************/

/* UART shifts max 8 bits, Mark/Space functionality working if 9 selected */
#define STL_NUMBER_OF_DATA_BITS    ((8u > 8u) ? 8u : 8u)
#define STL_NUMBER_OF_STOP_BITS    (1u)

#if (STL_RXHW_ADDRESS_ENABLED)
    #define STL_RX_ADDRESS_MODE    (0u)
    #define STL_RX_HW_ADDRESS1     (0u)
    #define STL_RX_HW_ADDRESS2     (0u)
#endif /* (STL_RXHW_ADDRESS_ENABLED) */

#define STL_INIT_RX_INTERRUPTS_MASK \
                                  (uint8)((1 << STL_RX_STS_FIFO_NOTEMPTY_SHIFT) \
                                        | (0 << STL_RX_STS_MRKSPC_SHIFT) \
                                        | (0 << STL_RX_STS_ADDR_MATCH_SHIFT) \
                                        | (0 << STL_RX_STS_PAR_ERROR_SHIFT) \
                                        | (0 << STL_RX_STS_STOP_ERROR_SHIFT) \
                                        | (0 << STL_RX_STS_BREAK_SHIFT) \
                                        | (0 << STL_RX_STS_OVERRUN_SHIFT))

#define STL_INIT_TX_INTERRUPTS_MASK \
                                  (uint8)((0 << STL_TX_STS_COMPLETE_SHIFT) \
                                        | (0 << STL_TX_STS_FIFO_EMPTY_SHIFT) \
                                        | (0 << STL_TX_STS_FIFO_FULL_SHIFT) \
                                        | (0 << STL_TX_STS_FIFO_NOT_FULL_SHIFT))


/***************************************
*              Registers
***************************************/

#ifdef STL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define STL_CONTROL_REG \
                            (* (reg8 *) STL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
    #define STL_CONTROL_PTR \
                            (  (reg8 *) STL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG )
#endif /* End STL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(STL_TX_ENABLED)
    #define STL_TXDATA_REG          (* (reg8 *) STL_BUART_sTX_TxShifter_u0__F0_REG)
    #define STL_TXDATA_PTR          (  (reg8 *) STL_BUART_sTX_TxShifter_u0__F0_REG)
    #define STL_TXDATA_AUX_CTL_REG  (* (reg8 *) STL_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define STL_TXDATA_AUX_CTL_PTR  (  (reg8 *) STL_BUART_sTX_TxShifter_u0__DP_AUX_CTL_REG)
    #define STL_TXSTATUS_REG        (* (reg8 *) STL_BUART_sTX_TxSts__STATUS_REG)
    #define STL_TXSTATUS_PTR        (  (reg8 *) STL_BUART_sTX_TxSts__STATUS_REG)
    #define STL_TXSTATUS_MASK_REG   (* (reg8 *) STL_BUART_sTX_TxSts__MASK_REG)
    #define STL_TXSTATUS_MASK_PTR   (  (reg8 *) STL_BUART_sTX_TxSts__MASK_REG)
    #define STL_TXSTATUS_ACTL_REG   (* (reg8 *) STL_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)
    #define STL_TXSTATUS_ACTL_PTR   (  (reg8 *) STL_BUART_sTX_TxSts__STATUS_AUX_CTL_REG)

    /* DP clock */
    #if(STL_TXCLKGEN_DP)
        #define STL_TXBITCLKGEN_CTR_REG        \
                                        (* (reg8 *) STL_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define STL_TXBITCLKGEN_CTR_PTR        \
                                        (  (reg8 *) STL_BUART_sTX_sCLOCK_TxBitClkGen__D0_REG)
        #define STL_TXBITCLKTX_COMPLETE_REG    \
                                        (* (reg8 *) STL_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
        #define STL_TXBITCLKTX_COMPLETE_PTR    \
                                        (  (reg8 *) STL_BUART_sTX_sCLOCK_TxBitClkGen__D1_REG)
    #else     /* Count7 clock*/
        #define STL_TXBITCTR_PERIOD_REG    \
                                        (* (reg8 *) STL_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define STL_TXBITCTR_PERIOD_PTR    \
                                        (  (reg8 *) STL_BUART_sTX_sCLOCK_TxBitCounter__PERIOD_REG)
        #define STL_TXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) STL_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define STL_TXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) STL_BUART_sTX_sCLOCK_TxBitCounter__CONTROL_AUX_CTL_REG)
        #define STL_TXBITCTR_COUNTER_REG   \
                                        (* (reg8 *) STL_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
        #define STL_TXBITCTR_COUNTER_PTR   \
                                        (  (reg8 *) STL_BUART_sTX_sCLOCK_TxBitCounter__COUNT_REG)
    #endif /* STL_TXCLKGEN_DP */

#endif /* End STL_TX_ENABLED */

#if(STL_HD_ENABLED)

    #define STL_TXDATA_REG             (* (reg8 *) STL_BUART_sRX_RxShifter_u0__F1_REG )
    #define STL_TXDATA_PTR             (  (reg8 *) STL_BUART_sRX_RxShifter_u0__F1_REG )
    #define STL_TXDATA_AUX_CTL_REG     (* (reg8 *) STL_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)
    #define STL_TXDATA_AUX_CTL_PTR     (  (reg8 *) STL_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define STL_TXSTATUS_REG           (* (reg8 *) STL_BUART_sRX_RxSts__STATUS_REG )
    #define STL_TXSTATUS_PTR           (  (reg8 *) STL_BUART_sRX_RxSts__STATUS_REG )
    #define STL_TXSTATUS_MASK_REG      (* (reg8 *) STL_BUART_sRX_RxSts__MASK_REG )
    #define STL_TXSTATUS_MASK_PTR      (  (reg8 *) STL_BUART_sRX_RxSts__MASK_REG )
    #define STL_TXSTATUS_ACTL_REG      (* (reg8 *) STL_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define STL_TXSTATUS_ACTL_PTR      (  (reg8 *) STL_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End STL_HD_ENABLED */

#if( (STL_RX_ENABLED) || (STL_HD_ENABLED) )
    #define STL_RXDATA_REG             (* (reg8 *) STL_BUART_sRX_RxShifter_u0__F0_REG )
    #define STL_RXDATA_PTR             (  (reg8 *) STL_BUART_sRX_RxShifter_u0__F0_REG )
    #define STL_RXADDRESS1_REG         (* (reg8 *) STL_BUART_sRX_RxShifter_u0__D0_REG )
    #define STL_RXADDRESS1_PTR         (  (reg8 *) STL_BUART_sRX_RxShifter_u0__D0_REG )
    #define STL_RXADDRESS2_REG         (* (reg8 *) STL_BUART_sRX_RxShifter_u0__D1_REG )
    #define STL_RXADDRESS2_PTR         (  (reg8 *) STL_BUART_sRX_RxShifter_u0__D1_REG )
    #define STL_RXDATA_AUX_CTL_REG     (* (reg8 *) STL_BUART_sRX_RxShifter_u0__DP_AUX_CTL_REG)

    #define STL_RXBITCTR_PERIOD_REG    (* (reg8 *) STL_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define STL_RXBITCTR_PERIOD_PTR    (  (reg8 *) STL_BUART_sRX_RxBitCounter__PERIOD_REG )
    #define STL_RXBITCTR_CONTROL_REG   \
                                        (* (reg8 *) STL_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define STL_RXBITCTR_CONTROL_PTR   \
                                        (  (reg8 *) STL_BUART_sRX_RxBitCounter__CONTROL_AUX_CTL_REG )
    #define STL_RXBITCTR_COUNTER_REG   (* (reg8 *) STL_BUART_sRX_RxBitCounter__COUNT_REG )
    #define STL_RXBITCTR_COUNTER_PTR   (  (reg8 *) STL_BUART_sRX_RxBitCounter__COUNT_REG )

    #define STL_RXSTATUS_REG           (* (reg8 *) STL_BUART_sRX_RxSts__STATUS_REG )
    #define STL_RXSTATUS_PTR           (  (reg8 *) STL_BUART_sRX_RxSts__STATUS_REG )
    #define STL_RXSTATUS_MASK_REG      (* (reg8 *) STL_BUART_sRX_RxSts__MASK_REG )
    #define STL_RXSTATUS_MASK_PTR      (  (reg8 *) STL_BUART_sRX_RxSts__MASK_REG )
    #define STL_RXSTATUS_ACTL_REG      (* (reg8 *) STL_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
    #define STL_RXSTATUS_ACTL_PTR      (  (reg8 *) STL_BUART_sRX_RxSts__STATUS_AUX_CTL_REG )
#endif /* End  (STL_RX_ENABLED) || (STL_HD_ENABLED) */

#if(STL_INTERNAL_CLOCK_USED)
    /* Register to enable or disable the digital clocks */
    #define STL_INTCLOCK_CLKEN_REG     (* (reg8 *) STL_IntClock__PM_ACT_CFG)
    #define STL_INTCLOCK_CLKEN_PTR     (  (reg8 *) STL_IntClock__PM_ACT_CFG)

    /* Clock mask for this clock. */
    #define STL_INTCLOCK_CLKEN_MASK    STL_IntClock__PM_ACT_MSK
#endif /* End STL_INTERNAL_CLOCK_USED */


/***************************************
*       Register Constants
***************************************/

#if(STL_TX_ENABLED)
    #define STL_TX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End STL_TX_ENABLED */

#if(STL_HD_ENABLED)
    #define STL_TX_FIFO_CLR            (0x02u) /* FIFO1 CLR */
#endif /* End STL_HD_ENABLED */

#if( (STL_RX_ENABLED) || (STL_HD_ENABLED) )
    #define STL_RX_FIFO_CLR            (0x01u) /* FIFO0 CLR */
#endif /* End  (STL_RX_ENABLED) || (STL_HD_ENABLED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

/* UART v2_40 obsolete definitions */
#define STL_WAIT_1_MS      STL_BL_CHK_DELAY_MS   

#define STL_TXBUFFERSIZE   STL_TX_BUFFER_SIZE
#define STL_RXBUFFERSIZE   STL_RX_BUFFER_SIZE

#if (STL_RXHW_ADDRESS_ENABLED)
    #define STL_RXADDRESSMODE  STL_RX_ADDRESS_MODE
    #define STL_RXHWADDRESS1   STL_RX_HW_ADDRESS1
    #define STL_RXHWADDRESS2   STL_RX_HW_ADDRESS2
    /* Backward compatible define */
    #define STL_RXAddressMode  STL_RXADDRESSMODE
#endif /* (STL_RXHW_ADDRESS_ENABLED) */

/* UART v2_30 obsolete definitions */
#define STL_initvar                    STL_initVar

#define STL_RX_Enabled                 STL_RX_ENABLED
#define STL_TX_Enabled                 STL_TX_ENABLED
#define STL_HD_Enabled                 STL_HD_ENABLED
#define STL_RX_IntInterruptEnabled     STL_RX_INTERRUPT_ENABLED
#define STL_TX_IntInterruptEnabled     STL_TX_INTERRUPT_ENABLED
#define STL_InternalClockUsed          STL_INTERNAL_CLOCK_USED
#define STL_RXHW_Address_Enabled       STL_RXHW_ADDRESS_ENABLED
#define STL_OverSampleCount            STL_OVER_SAMPLE_COUNT
#define STL_ParityType                 STL_PARITY_TYPE

#if( STL_TX_ENABLED && (STL_TXBUFFERSIZE > STL_FIFO_LENGTH))
    #define STL_TXBUFFER               STL_txBuffer
    #define STL_TXBUFFERREAD           STL_txBufferRead
    #define STL_TXBUFFERWRITE          STL_txBufferWrite
#endif /* End STL_TX_ENABLED */
#if( ( STL_RX_ENABLED || STL_HD_ENABLED ) && \
     (STL_RXBUFFERSIZE > STL_FIFO_LENGTH) )
    #define STL_RXBUFFER               STL_rxBuffer
    #define STL_RXBUFFERREAD           STL_rxBufferRead
    #define STL_RXBUFFERWRITE          STL_rxBufferWrite
    #define STL_RXBUFFERLOOPDETECT     STL_rxBufferLoopDetect
    #define STL_RXBUFFER_OVERFLOW      STL_rxBufferOverflow
#endif /* End STL_RX_ENABLED */

#ifdef STL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG
    #define STL_CONTROL                STL_CONTROL_REG
#endif /* End STL_BUART_sCR_SyncCtl_CtrlReg__CONTROL_REG */

#if(STL_TX_ENABLED)
    #define STL_TXDATA                 STL_TXDATA_REG
    #define STL_TXSTATUS               STL_TXSTATUS_REG
    #define STL_TXSTATUS_MASK          STL_TXSTATUS_MASK_REG
    #define STL_TXSTATUS_ACTL          STL_TXSTATUS_ACTL_REG
    /* DP clock */
    #if(STL_TXCLKGEN_DP)
        #define STL_TXBITCLKGEN_CTR        STL_TXBITCLKGEN_CTR_REG
        #define STL_TXBITCLKTX_COMPLETE    STL_TXBITCLKTX_COMPLETE_REG
    #else     /* Count7 clock*/
        #define STL_TXBITCTR_PERIOD        STL_TXBITCTR_PERIOD_REG
        #define STL_TXBITCTR_CONTROL       STL_TXBITCTR_CONTROL_REG
        #define STL_TXBITCTR_COUNTER       STL_TXBITCTR_COUNTER_REG
    #endif /* STL_TXCLKGEN_DP */
#endif /* End STL_TX_ENABLED */

#if(STL_HD_ENABLED)
    #define STL_TXDATA                 STL_TXDATA_REG
    #define STL_TXSTATUS               STL_TXSTATUS_REG
    #define STL_TXSTATUS_MASK          STL_TXSTATUS_MASK_REG
    #define STL_TXSTATUS_ACTL          STL_TXSTATUS_ACTL_REG
#endif /* End STL_HD_ENABLED */

#if( (STL_RX_ENABLED) || (STL_HD_ENABLED) )
    #define STL_RXDATA                 STL_RXDATA_REG
    #define STL_RXADDRESS1             STL_RXADDRESS1_REG
    #define STL_RXADDRESS2             STL_RXADDRESS2_REG
    #define STL_RXBITCTR_PERIOD        STL_RXBITCTR_PERIOD_REG
    #define STL_RXBITCTR_CONTROL       STL_RXBITCTR_CONTROL_REG
    #define STL_RXBITCTR_COUNTER       STL_RXBITCTR_COUNTER_REG
    #define STL_RXSTATUS               STL_RXSTATUS_REG
    #define STL_RXSTATUS_MASK          STL_RXSTATUS_MASK_REG
    #define STL_RXSTATUS_ACTL          STL_RXSTATUS_ACTL_REG
#endif /* End  (STL_RX_ENABLED) || (STL_HD_ENABLED) */

#if(STL_INTERNAL_CLOCK_USED)
    #define STL_INTCLOCK_CLKEN         STL_INTCLOCK_CLKEN_REG
#endif /* End STL_INTERNAL_CLOCK_USED */

#define STL_WAIT_FOR_COMLETE_REINIT    STL_WAIT_FOR_COMPLETE_REINIT

#endif  /* CY_UART_STL_H */


/* [] END OF FILE */
