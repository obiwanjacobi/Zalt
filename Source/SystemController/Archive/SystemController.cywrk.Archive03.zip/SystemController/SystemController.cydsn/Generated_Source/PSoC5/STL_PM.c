/*******************************************************************************
* File Name: STL_PM.c
* Version 2.50
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "STL.h"


/***************************************
* Local data allocation
***************************************/

static STL_BACKUP_STRUCT  STL_backup =
{
    /* enableState - disabled */
    0u,
};



/*******************************************************************************
* Function Name: STL_SaveConfig
********************************************************************************
*
* Summary:
*  This function saves the component nonretention control register.
*  Does not save the FIFO which is a set of nonretention registers.
*  This function is called by the STL_Sleep() function.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  STL_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void STL_SaveConfig(void)
{
    #if(STL_CONTROL_REG_REMOVED == 0u)
        STL_backup.cr = STL_CONTROL_REG;
    #endif /* End STL_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: STL_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the nonretention control register except FIFO.
*  Does not restore the FIFO which is a set of nonretention registers.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  STL_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
* Notes:
*  If this function is called without calling STL_SaveConfig() 
*  first, the data loaded may be incorrect.
*
*******************************************************************************/
void STL_RestoreConfig(void)
{
    #if(STL_CONTROL_REG_REMOVED == 0u)
        STL_CONTROL_REG = STL_backup.cr;
    #endif /* End STL_CONTROL_REG_REMOVED */
}


/*******************************************************************************
* Function Name: STL_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred API to prepare the component for sleep. 
*  The STL_Sleep() API saves the current component state. Then it
*  calls the STL_Stop() function and calls 
*  STL_SaveConfig() to save the hardware configuration.
*  Call the STL_Sleep() function before calling the CyPmSleep() 
*  or the CyPmHibernate() function. 
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  STL_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void STL_Sleep(void)
{
    #if(STL_RX_ENABLED || STL_HD_ENABLED)
        if((STL_RXSTATUS_ACTL_REG  & STL_INT_ENABLE) != 0u)
        {
            STL_backup.enableState = 1u;
        }
        else
        {
            STL_backup.enableState = 0u;
        }
    #else
        if((STL_TXSTATUS_ACTL_REG  & STL_INT_ENABLE) !=0u)
        {
            STL_backup.enableState = 1u;
        }
        else
        {
            STL_backup.enableState = 0u;
        }
    #endif /* End STL_RX_ENABLED || STL_HD_ENABLED*/

    STL_Stop();
    STL_SaveConfig();
}


/*******************************************************************************
* Function Name: STL_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred API to restore the component to the state when 
*  STL_Sleep() was called. The STL_Wakeup() function
*  calls the STL_RestoreConfig() function to restore the 
*  configuration. If the component was enabled before the 
*  STL_Sleep() function was called, the STL_Wakeup()
*  function will also re-enable the component.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  STL_backup - used when non-retention registers are restored.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void STL_Wakeup(void)
{
    STL_RestoreConfig();
    #if( (STL_RX_ENABLED) || (STL_HD_ENABLED) )
        STL_ClearRxBuffer();
    #endif /* End (STL_RX_ENABLED) || (STL_HD_ENABLED) */
    #if(STL_TX_ENABLED || STL_HD_ENABLED)
        STL_ClearTxBuffer();
    #endif /* End STL_TX_ENABLED || STL_HD_ENABLED */

    if(STL_backup.enableState != 0u)
    {
        STL_Enable();
    }
}


/* [] END OF FILE */
