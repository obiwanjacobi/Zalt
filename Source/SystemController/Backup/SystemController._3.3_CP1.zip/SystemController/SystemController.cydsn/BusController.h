#ifndef __BUSCONTROLLER_H__
#define __BUSCONTROLLER_H__

#include <project.h>

// TODO: Wait-state management
    
void BusController_Init();
    
// sync acquire the external bus
void BusController_Acquire();

// sync release the external bus
void BusController_Release();

// indicates if the bus is acquired (non-zero)
uint8_t BusController_IsAcquired();

// enable data bus outputs for write
inline void BusController_EnableDataBusOutput(uint8_t enable);

#endif  //__BUSCONTROLLER_H__

/* [] END OF FILE */
