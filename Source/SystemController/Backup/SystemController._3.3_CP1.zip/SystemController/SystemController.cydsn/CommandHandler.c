#include "CommandHandler.h"
#include "CommandParser.h"
#include "BusController.h"
#include "MemoryController.h"
#include "CpuController.h"

#include <stdlib.h>

static const char* OK = "OK";
static const char* ACK = "ACK";
static const char* SUSPENDED = "Suspended";

//
// DMA Commands
//

uint16_t DmaParseCommandParameters(RingBuffer* buffer, TerminalCommand* command)
{
    uint16_t totalRead = 0;
    char* endPtr = NULL;
    uint8_t temp[10];
    
    // read command parameters (TODO: command specific?)
    if (!RingBuffer_IsEmpty(buffer))
    {
        totalRead += CommandParser_Read(buffer, temp, 9);
        command->Address = strtoul((const char*)temp, &endPtr, 16);
        
        if (!RingBuffer_IsEmpty(buffer))
        {
            totalRead += CommandParser_Read(buffer, temp, 9);
            command->Length = strtoul((const char*)temp, &endPtr, 16);
        }
    }
    
    return totalRead;
}

uint8_t MemoryWrite_WriteByte(void* ctx, uint8_t data)
{
    Memory* mem = (Memory*)ctx;
    
    MemoryController_WriteByte(mem, data);
    SysTerminal_PutChar(data);
    
    return mem->Length > 0;
}

//
// Memory Write
//
// => 'mw' <Address> <Length>
// <= "ACK"
// => blob
uint16_t MemoryWrite_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    Memory mem;
    mem.Address = command->Address;
    mem.Buffer = NULL;
    mem.Length = command->Length;
    
    if (mem.Length == 0) return 0;

    uint8_t releaseBusWhenDone = !BusController_IsAcquired();
    if (releaseBusWhenDone)
    {
        BusController_Acquire();
    }
    
    // signal ready to receive file
    SerialTerminal_WriteLine(ACK);

    uint16_t bytesRead = SerialTerminal_ReceiveBlob(&mem, MemoryWrite_WriteByte);
    
    // block until all bytes have been read
    while(mem.Length > 0)  //(bytesRead < command->Length)
    {
        bytesRead += SerialTerminal_ReceiveBlob(&mem, MemoryWrite_WriteByte);
    }
    
    if (releaseBusWhenDone)
    {
        BusController_Release();
    }
    
    SerialTerminal_WriteLine(OK);
    
    return 0;
}

//
// Memory Read
//
// => 'mr' <Address> <Length>
// <= blob
uint16_t MemoryRead_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    const int BufferSize = SysTerminal_RX_BUFFER_SIZE / 2;
    uint8_t buffer[BufferSize];
    uint16_t lengthToGo = command->Length;
    uint16_t length = 0;
    uint16_t bytesRead = 0;
    Memory mem;
    
    uint8_t releaseBusWhenDone = !BusController_IsAcquired();
    if (releaseBusWhenDone)
    {
        BusController_Acquire();
    }
    
    while(lengthToGo > 0)
    {
        length = lengthToGo > BufferSize ? BufferSize : lengthToGo;
        
        mem.Address = command->Address + bytesRead;
        mem.Buffer = buffer;
        mem.Length = length;
        
        MemoryController_Read(&mem);
        SysTerminal_PutArray(buffer, length);
        
        lengthToGo -= length;
        bytesRead += length;
    }
    
    if (releaseBusWhenDone)
    {
        BusController_Release();
    }
    
    SerialTerminal_WriteLine("\r\n");
    
    return 0;
}

//
// CPU Control Commands
//

static const char* ClkMode_Step = "step";
static const char* ClkMode_Fast = "fast";
static const char* ClkMode_Slow = "slow";


//
// Clock Mode
//
// => 'cm' [Step]|[Fast]|[Slow]
uint16_t ClockMode_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    RingBuffer* const buffer = &serialTerminal->RxBuffer;
    uint16_t totalRead = 0;
    uint8_t temp[6];
    
    command->Param3 = 0;
    command->Mode = 0;
    
    if (!RingBuffer_IsEmpty(buffer))
    {
        totalRead += CommandParser_Read(buffer, temp, 5);
        
        if (strcasecmp((const char*)temp, ClkMode_Fast) == 0)
            command->Mode = CPUMODE_NORMAL_FAST;
        if (strcasecmp((const char*)temp, ClkMode_Slow) == 0)
            command->Mode = CPUMODE_NORMAL_SLOW;
        if (strcasecmp((const char*)temp, ClkMode_Step) == 0)
            command->Mode = CPUMODE_STEP;
        
        CpuController_SetClockMode(command->Mode);
    }
    
    SerialTerminal_WriteLine(OK);
    
    return totalRead;
}

//
// Clock Divider
//
// => 'cd' [0]|[1]|[2]|[3]
uint16_t ClockDivider_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    RingBuffer* const buffer = &serialTerminal->RxBuffer;
    uint16_t totalRead = 0;
    uint8_t temp[10];
    char* endPtr = NULL;
    
    command->Number = 0;
    command->Param3 = 0;
    
    if (!RingBuffer_IsEmpty(buffer))
    {
        totalRead += CommandParser_Read(buffer, temp, 9);
        
        command->Number = strtoul((const char*)temp, &endPtr, 10);
        
        CpuController_SetClockDivider((uint8_t)command->Number);
    }
    
    SerialTerminal_WriteLine(OK);
    
    return totalRead;
}

//
// Clock Pulse
//
// => 'cp' [<number of pulses>]
uint16_t ClockPulse_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    RingBuffer* const buffer = &serialTerminal->RxBuffer;
    uint16_t totalRead = 0;
    uint8_t temp[10];
    char* endPtr = NULL;
    
    command->Number = 1;
    command->Param3 = 0;
    
    if (!RingBuffer_IsEmpty(buffer))
    {
        totalRead += CommandParser_Read(buffer, temp, 9);
        
        command->Number = strtoul((const char*)temp, &endPtr, 10);
    }
    
    CpuController_PulseClock(command->Number);
    
    SerialTerminal_WriteLine(OK);
    
    return totalRead;
}

//
// CPU Reset
//
// => 'rst' [n]     (n = number of clock cycles to keep the reset active) 0 = latch active
uint16_t CpuReset_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    RingBuffer* const buffer = &serialTerminal->RxBuffer;
    uint16_t totalRead = 0;
    uint8_t temp[10];
    char* endPtr = NULL;
    
    uint16_t number = 4;
    
    if (!RingBuffer_IsEmpty(buffer))
    {
        totalRead += CommandParser_Read(buffer, temp, 9);
        
        command->Number = strtoul((const char*)temp, &endPtr, 10);
        number = command->Number;
    }
    
    CpuController_Reset(1);
    
    if (number > 0)
    {
        // give Z80 enough time to reset.
        CpuController_WaitCycles(number);
        CpuController_Reset(0);
        
        SerialTerminal_WriteLine(OK);
    }
    else
    {
        SerialTerminal_WriteLine(SUSPENDED);
    }
    
    return totalRead;
}

//
// Dispatcher entry point
//
uint16_t CommandHandler_DispatchCommand(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    uint16_t bytesRead = 0;
    
    switch(command->Command)
    {
        case COMMAND_MEMORYWRITE:
            bytesRead = DmaParseCommandParameters(&serialTerminal->RxBuffer, command);
            MemoryWrite_Execute(serialTerminal, command);
            break;
        case COMMAND_MEMORYREAD:
            bytesRead = DmaParseCommandParameters(&serialTerminal->RxBuffer, command);
            MemoryRead_Execute(serialTerminal, command);
            break;
        case COMMAND_CLOCKMODE:
            bytesRead = ClockMode_Execute(serialTerminal, command);
            break;
        case COMMAND_CLOCKDIVIDER:
            bytesRead = ClockDivider_Execute(serialTerminal, command);
            break;
        case COMMAND_CLOCKPULSE:
            bytesRead = ClockPulse_Execute(serialTerminal, command);
            break;
        case COMMAND_CPURESET:
            bytesRead = CpuReset_Execute(serialTerminal, command);
            break;
    }
    
    return bytesRead;
}

/* [] END OF FILE */
