/*******************************************************************************
* File Name: CPUCLK_FAST.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_CPUCLK_FAST_H)
#define CY_CLOCK_CPUCLK_FAST_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void CPUCLK_FAST_Start(void) ;
void CPUCLK_FAST_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void CPUCLK_FAST_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void CPUCLK_FAST_StandbyPower(uint8 state) ;
void CPUCLK_FAST_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 CPUCLK_FAST_GetDividerRegister(void) ;
void CPUCLK_FAST_SetModeRegister(uint8 modeBitMask) ;
void CPUCLK_FAST_ClearModeRegister(uint8 modeBitMask) ;
uint8 CPUCLK_FAST_GetModeRegister(void) ;
void CPUCLK_FAST_SetSourceRegister(uint8 clkSource) ;
uint8 CPUCLK_FAST_GetSourceRegister(void) ;
#if defined(CPUCLK_FAST__CFG3)
void CPUCLK_FAST_SetPhaseRegister(uint8 clkPhase) ;
uint8 CPUCLK_FAST_GetPhaseRegister(void) ;
#endif /* defined(CPUCLK_FAST__CFG3) */

#define CPUCLK_FAST_Enable()                       CPUCLK_FAST_Start()
#define CPUCLK_FAST_Disable()                      CPUCLK_FAST_Stop()
#define CPUCLK_FAST_SetDivider(clkDivider)         CPUCLK_FAST_SetDividerRegister(clkDivider, 1u)
#define CPUCLK_FAST_SetDividerValue(clkDivider)    CPUCLK_FAST_SetDividerRegister((clkDivider) - 1u, 1u)
#define CPUCLK_FAST_SetMode(clkMode)               CPUCLK_FAST_SetModeRegister(clkMode)
#define CPUCLK_FAST_SetSource(clkSource)           CPUCLK_FAST_SetSourceRegister(clkSource)
#if defined(CPUCLK_FAST__CFG3)
#define CPUCLK_FAST_SetPhase(clkPhase)             CPUCLK_FAST_SetPhaseRegister(clkPhase)
#define CPUCLK_FAST_SetPhaseValue(clkPhase)        CPUCLK_FAST_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(CPUCLK_FAST__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define CPUCLK_FAST_CLKEN              (* (reg8 *) CPUCLK_FAST__PM_ACT_CFG)
#define CPUCLK_FAST_CLKEN_PTR          ((reg8 *) CPUCLK_FAST__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define CPUCLK_FAST_CLKSTBY            (* (reg8 *) CPUCLK_FAST__PM_STBY_CFG)
#define CPUCLK_FAST_CLKSTBY_PTR        ((reg8 *) CPUCLK_FAST__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define CPUCLK_FAST_DIV_LSB            (* (reg8 *) CPUCLK_FAST__CFG0)
#define CPUCLK_FAST_DIV_LSB_PTR        ((reg8 *) CPUCLK_FAST__CFG0)
#define CPUCLK_FAST_DIV_PTR            ((reg16 *) CPUCLK_FAST__CFG0)

/* Clock MSB divider configuration register. */
#define CPUCLK_FAST_DIV_MSB            (* (reg8 *) CPUCLK_FAST__CFG1)
#define CPUCLK_FAST_DIV_MSB_PTR        ((reg8 *) CPUCLK_FAST__CFG1)

/* Mode and source configuration register */
#define CPUCLK_FAST_MOD_SRC            (* (reg8 *) CPUCLK_FAST__CFG2)
#define CPUCLK_FAST_MOD_SRC_PTR        ((reg8 *) CPUCLK_FAST__CFG2)

#if defined(CPUCLK_FAST__CFG3)
/* Analog clock phase configuration register */
#define CPUCLK_FAST_PHASE              (* (reg8 *) CPUCLK_FAST__CFG3)
#define CPUCLK_FAST_PHASE_PTR          ((reg8 *) CPUCLK_FAST__CFG3)
#endif /* defined(CPUCLK_FAST__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define CPUCLK_FAST_CLKEN_MASK         CPUCLK_FAST__PM_ACT_MSK
#define CPUCLK_FAST_CLKSTBY_MASK       CPUCLK_FAST__PM_STBY_MSK

/* CFG2 field masks */
#define CPUCLK_FAST_SRC_SEL_MSK        CPUCLK_FAST__CFG2_SRC_SEL_MASK
#define CPUCLK_FAST_MODE_MASK          (~(CPUCLK_FAST_SRC_SEL_MSK))

#if defined(CPUCLK_FAST__CFG3)
/* CFG3 phase mask */
#define CPUCLK_FAST_PHASE_MASK         CPUCLK_FAST__CFG3_PHASE_DLY_MASK
#endif /* defined(CPUCLK_FAST__CFG3) */

#endif /* CY_CLOCK_CPUCLK_FAST_H */


/* [] END OF FILE */
