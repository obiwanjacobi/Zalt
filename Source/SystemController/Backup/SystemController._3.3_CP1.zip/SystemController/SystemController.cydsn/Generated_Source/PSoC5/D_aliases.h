/*******************************************************************************
* File Name: D.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_D_ALIASES_H) /* Pins D_ALIASES_H */
#define CY_PINS_D_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"



/***************************************
*              Constants        
***************************************/
#define D_0		(D__0__PC)
#define D_1		(D__1__PC)
#define D_2		(D__2__PC)
#define D_3		(D__3__PC)
#define D_4		(D__4__PC)
#define D_5		(D__5__PC)
#define D_6		(D__6__PC)
#define D_7		(D__7__PC)

#endif /* End Pins D_ALIASES_H */

/* [] END OF FILE */
