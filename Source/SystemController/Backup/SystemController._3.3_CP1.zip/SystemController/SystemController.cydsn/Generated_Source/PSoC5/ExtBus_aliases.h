/*******************************************************************************
* File Name: ExtBus.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ExtBus_ALIASES_H) /* Pins ExtBus_ALIASES_H */
#define CY_PINS_ExtBus_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"



/***************************************
*              Constants        
***************************************/
#define ExtBus_0		(ExtBus__0__PC)
#define ExtBus_1		(ExtBus__1__PC)
#define ExtBus_2		(ExtBus__2__PC)
#define ExtBus_3		(ExtBus__3__PC)
#define ExtBus_4		(ExtBus__4__PC)
#define ExtBus_5		(ExtBus__5__PC)
#define ExtBus_6		(ExtBus__6__PC)
#define ExtBus_7		(ExtBus__7__PC)
#define ExtBus_8		(ExtBus__8__PC)

#define ExtBus_MemReq		(ExtBus__MemReq__PC)
#define ExtBus_IoReq		(ExtBus__IoReq__PC)
#define ExtBus_Rd		(ExtBus__Rd__PC)
#define ExtBus_Wr		(ExtBus__Wr__PC)
#define ExtBus_BusReq		(ExtBus__BusReq__PC)
#define ExtBus_BusAck		(ExtBus__BusAck__PC)
#define ExtBus_CpuHalt		(ExtBus__CpuHalt__PC)
#define ExtBus_CpuClk		(ExtBus__CpuClk__PC)
#define ExtBus_CpuRst		(ExtBus__CpuRst__PC)

#endif /* End Pins ExtBus_ALIASES_H */

/* [] END OF FILE */
