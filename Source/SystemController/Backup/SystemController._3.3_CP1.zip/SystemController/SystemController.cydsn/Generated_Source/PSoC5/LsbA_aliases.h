/*******************************************************************************
* File Name: LsbA.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LsbA_ALIASES_H) /* Pins LsbA_ALIASES_H */
#define CY_PINS_LsbA_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"



/***************************************
*              Constants        
***************************************/
#define LsbA_0		(LsbA__0__PC)
#define LsbA_1		(LsbA__1__PC)
#define LsbA_2		(LsbA__2__PC)
#define LsbA_3		(LsbA__3__PC)
#define LsbA_4		(LsbA__4__PC)
#define LsbA_5		(LsbA__5__PC)
#define LsbA_6		(LsbA__6__PC)
#define LsbA_7		(LsbA__7__PC)

#endif /* End Pins LsbA_ALIASES_H */

/* [] END OF FILE */
