/*******************************************************************************
* File Name: MsbA.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_MsbA_ALIASES_H) /* Pins MsbA_ALIASES_H */
#define CY_PINS_MsbA_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"



/***************************************
*              Constants        
***************************************/
#define MsbA_0		(MsbA__0__PC)
#define MsbA_1		(MsbA__1__PC)
#define MsbA_2		(MsbA__2__PC)
#define MsbA_3		(MsbA__3__PC)
#define MsbA_4		(MsbA__4__PC)
#define MsbA_5		(MsbA__5__PC)
#define MsbA_6		(MsbA__6__PC)
#define MsbA_7		(MsbA__7__PC)

#endif /* End Pins MsbA_ALIASES_H */

/* [] END OF FILE */
