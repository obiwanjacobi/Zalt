#ifndef __IOCONTROLLER_H__
#define __IOCONTROLLER_H__
    
#include <project.h>

#define IO_MODE_IN      0   // Data is not valid
#define IO_MODE_OUT     1   // Data is valid
#define IO_MODE_NEW     0x80    // flag to indicate new data available
    
typedef struct
{
    uint8_t Mode;   // IO_MODE_X
    uint8_t Address;
    uint8_t Data;
    
} IOInfo;
    
//
// IO Addresses for SystemController peripherals
//

// test loop IO address
#define IO_TEST_LOOP    0x00

// fixed serial commlink to PC
#define IO_Serial       0x20

void IOController_Init();

// for system use, don't call
inline void IOController_ISR_OnIOInterrupt();
inline void IOController_Output(IOInfo* ioInfo);
inline void IOController_Input(IOInfo* ioInfo);
    
#endif  //__IOCONTROLLER_H__

/* [] END OF FILE */
