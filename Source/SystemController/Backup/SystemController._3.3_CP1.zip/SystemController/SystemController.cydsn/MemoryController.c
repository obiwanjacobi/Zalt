#include "MemoryController.h"
#include "BusController.h"

uint8_t MemCtrl_Read(uint16_t address)
{
    BusController_EnableDataBusOutput(0);
    CyPins_SetPin(ExtBus_Wr);
    
    LsbA_Write(address & 0x00FF);
    MsbA_Write((address & 0xFF00) >> 8);
    
    CyPins_ClearPin(ExtBus_MemReq);
    CyPins_ClearPin(ExtBus_Rd);
    
    uint8_t data = D_Read();
    
    CyPins_SetPin(ExtBus_Rd);
    CyPins_SetPin(ExtBus_MemReq);
    
    return data;
}

void MemCtrl_Write(uint16_t address, uint8_t data)
{
    BusController_EnableDataBusOutput(1);
    CyPins_SetPin(ExtBus_Rd);
    
    LsbA_Write(address & 0x00FF);
    MsbA_Write((address & 0xFF00) >> 8);
    
    CyPins_ClearPin(ExtBus_MemReq);
    CyPins_ClearPin(ExtBus_Wr);
    
    D_Write(data);
    
    CyPins_SetPin(ExtBus_Wr);
    CyPins_SetPin(ExtBus_MemReq);
}

void MemoryController_Read(Memory* memory)
{
    uint8_t releaseBusWhenDone = !BusController_IsAcquired();
    if (releaseBusWhenDone)
    {
        BusController_Acquire();
    }
    
    uint16_t address = memory->Address;
    uint16_t i;
    for(i = 0; i < memory->Length; i++)
    {
        memory->Buffer[i] = MemCtrl_Read(address);
        address++;
    }
    
    if (releaseBusWhenDone)
    {
        BusController_Release();
    }
}

void MemoryController_Write(Memory* memory)
{
    uint8_t releaseBusWhenDone = !BusController_IsAcquired();
    if (releaseBusWhenDone)
    {
        BusController_Acquire();
    }
    
    uint16_t address = memory->Address;
    uint16_t i;
    for(i = 0; i < memory->Length; i++)
    {
        MemCtrl_Write(address, memory->Buffer[i]);
        address++;
    }
    
    if (releaseBusWhenDone)
    {
        BusController_Release();
    }
}

void MemoryController_WriteByte(Memory* memory, uint8_t data)
{
    MemCtrl_Write(memory->Address, data);
    memory->Address++;
    memory->Length--;
}

/* [] END OF FILE */
