#include <project.h>
#include "SerialTerminal.h"

#include "BusController.h"
#include "CpuController.h"
#include "MemoryController.h"
#include "IOController.h"

static SerialTerminal g_serialTerminal;

int main()
{
    CpuController_Init();
    BusController_Init();
    IOController_Init();
    
    SerialTerminal_Start(&g_serialTerminal);
    
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    // echo back that the system is ready but halted.
    SerialTerminal_WriteLine("Ready (stopped).");
    
    for(;;)
    {
        // pump incoming data to handlers
        SerialTerminal_ReceiveCommand(&g_serialTerminal);
    }
}

/* [] END OF FILE */
