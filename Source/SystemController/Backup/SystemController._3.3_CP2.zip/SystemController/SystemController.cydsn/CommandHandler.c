#include "CommandHandler.h"
#include "CommandParser.h"
#include "BusController.h"
#include "MemoryController.h"
#include "CpuController.h"
#include "IOController.h"

#include <stdlib.h>

static const char* OK = "OK";
static const char* ACK = "ACK";
static const char* SUSPENDED = "Suspended";
static const char* INCOMPLETE = "Command is Incomplete";

typedef struct  // extended Memory struct
{
    // Memory
    uint16_t Address;
    uint8_t* Buffer;
    uint16_t Length;
    // extension
    uint16_t SpinCountTimeout;
    
} WriteMemory;

//
// DMA Commands
//

uint16_t DmaParseCommandParameters(RingBuffer* buffer, TerminalCommand* command)
{
    uint16_t bytesRead = 0;
    command->Address = 0;
    command->Length = 0;
    command->Param3 = 0;
    
    if (!RingBuffer_IsEmpty(buffer))
    {
        char* endPtr = NULL;
        uint8_t temp[10];
    
        bytesRead += CommandParser_Read(buffer, temp, 9);
        command->Address = strtoul((const char*)temp, &endPtr, 16);
        
        if (!RingBuffer_IsEmpty(buffer))
        {
            bytesRead += CommandParser_Read(buffer, temp, 9);
            command->Length = strtoul((const char*)temp, &endPtr, 16);
            
            if (!RingBuffer_IsEmpty(buffer))
            {
                bytesRead += CommandParser_Read(buffer, temp, 9);
                command->Param3 = strtoul((const char*)temp, &endPtr, 16);
            }
        }
    }
        
    return bytesRead;
}

uint8_t MemoryWrite_WriteByte(void* ctx, uint8_t data)
{
    WriteMemory* mem = (WriteMemory*)ctx;
    
    if (mem->Length == 0 && mem->SpinCountTimeout != 0)
    {
        MemoryController_WriteByte((Memory*)mem, data);
        mem->Length = 0;
        return 1;
    }
    else
    {
        MemoryController_WriteByte((Memory*)mem, data);
    
        return mem->Length > 0;
    }
}

uint16_t MemoryRead_CopyToTerminal(uint16_t address, uint16_t length)
{
    const uint8_t BufferSize = 0xFF;
    uint8_t buffer[BufferSize];
    uint8_t l;
    uint16_t bytesRead = 0;
    Memory mem;
    mem.Buffer = buffer;
    
    while(length > 0)
    {
        l = length > BufferSize ? BufferSize : length;
                
        mem.Address = address + bytesRead;
        mem.Length = l;
        
        MemoryController_Read(&mem);
        //SysTerminal_PutArray(mem.Buffer, mem.Length);
        
        length -= l;
        bytesRead += l;
    }
    
    return bytesRead;
}

//
// Memory Write
//
// => 'mw' <Address> <Length>
// <= "ACK"
// => blob
// <= bytes
uint16_t MemoryWrite_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    WriteMemory mem;
    mem.Address = command->Address;
    mem.Buffer = NULL;
    mem.Length = command->Length;
    mem.SpinCountTimeout = mem.Length == 0 ? 0x1FF : 0;
    
    // signal ready to receive file
    SerialTerminal_WriteLine(ACK);
    BusState busState;
    BusController_Open(&busState);
    
    uint16_t bytesRead = 0;
    BusController_EnableDataBusOutput(1);
    
    // block until all bytes have been read
    while(mem.Length > 0 || mem.SpinCountTimeout > 0)
    {
        bytesRead += SerialTerminal_ReceiveBlob(&mem, MemoryWrite_WriteByte);
        
        if (bytesRead > 0 && mem.Length == 0 && mem.SpinCountTimeout > 0)
        {
            CyDelay(1);
            mem.SpinCountTimeout--;
        }
    }
    
    BusController_EnableDataBusOutput(0);
    
    MemoryRead_CopyToTerminal(command->Address, bytesRead);
    
    BusController_Close(&busState);
    
    SerialTerminal_WriteLine(NULL);
    SerialTerminal_WriteLine(OK);
    
    return 0;
}



//
// Memory Read
//
// => 'mr' <Address> <Length>
// <= blob
uint16_t MemoryRead_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    // some default for no length specified
    if (command->Length == 0)
    {
        command->Length = 0xFF;
    }
    
    BusState busState;
    BusController_Open(&busState);
    
    MemoryRead_CopyToTerminal(command->Address, command->Length);
    
    BusController_Close(&busState);
    
    SerialTerminal_WriteLine(NULL);
    SerialTerminal_WriteLine(OK);
    
    return 0;
}


//
// Memory Fill
//
// => 'mf' <Address> <Length> <char>
uint16_t MemoryFill_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    uint16_t bytesRead = 0;
    Memory mem;
    mem.Address = command->Address;
    mem.Buffer = NULL;
    mem.Length = command->Length == 0 ? 0xFFFF - command->Address : command->Length;
    
    BusState busState;
    BusController_Open(&busState);
    BusController_EnableDataBusOutput(1);
    
    while(mem.Length > 0)
    {
        MemoryController_WriteByte(&mem, command->Param3);
    }
    
    BusController_EnableDataBusOutput(0);
    BusController_Close(&busState);
    
    SerialTerminal_WriteLine(OK);
    
    return bytesRead;
}





//
// CPU Control Commands
//

static const char* ClkMode_Step = "step";
static const char* ClkMode_Fast = "fast";
static const char* ClkMode_Slow = "slow";
static const char* ClkMode_Off = "off";

//
// Clock Mode
//
// => 'cm' [Step]|[Fast]|[Slow]|[off]
uint16_t ClockMode_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    RingBuffer* const buffer = &serialTerminal->RxBuffer;
    uint16_t totalRead = 0;
    uint8_t temp[6];
    
    command->Param3 = 0;
    command->Mode = 0;
    
    if (!RingBuffer_IsEmpty(buffer))
    {
        totalRead += CommandParser_Read(buffer, temp, 5);
        
        if (strcasecmp((const char*)temp, ClkMode_Fast) == 0)
            command->Mode = CPUMODE_NORMAL_FAST;
        if (strcasecmp((const char*)temp, ClkMode_Slow) == 0)
            command->Mode = CPUMODE_NORMAL_SLOW;
        if (strcasecmp((const char*)temp, ClkMode_Step) == 0)
            command->Mode = CPUMODE_STEP;
        if (strcasecmp((const char*)temp, ClkMode_Off) == 0)
            command->Mode = CPUMODE_STEP;
        
        CpuController_SetClockMode(command->Mode);
    }
    
    SerialTerminal_WriteLine(OK);
    
    return totalRead;
}

//
// Clock Divider
//
// => 'cd' [0-7]
uint16_t ClockDivider_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    RingBuffer* const buffer = &serialTerminal->RxBuffer;
    uint16_t totalRead = 0;
    uint8_t temp[10];
    char* endPtr = NULL;
    
    command->Number = 0;
    command->Param3 = 0;
    
    if (!RingBuffer_IsEmpty(buffer))
    {
        totalRead += CommandParser_Read(buffer, temp, 9);
        
        command->Number = strtoul((const char*)temp, &endPtr, 10);
        
        CpuController_SetClockDivider((uint8_t)command->Number);
        
        SerialTerminal_WriteLine(OK);
    }
    else
    {
        SerialTerminal_WriteLine(INCOMPLETE);
    }
    
    return totalRead;
}

//
// Clock Pulse
//
// => 'cp' [<number of pulses>]
uint16_t ClockPulse_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    RingBuffer* const buffer = &serialTerminal->RxBuffer;
    uint16_t totalRead = 0;
    uint8_t temp[10];
    char* endPtr = NULL;
    
    command->Number = 1;
    command->Param3 = 0;
    
    if (!RingBuffer_IsEmpty(buffer))
    {
        totalRead += CommandParser_Read(buffer, temp, 9);
        
        command->Number = strtoul((const char*)temp, &endPtr, 10);
    }
    
    if (CpuController_GetClockMode() != CPUMODE_STEP)
    {
        CpuController_SetClockMode(CPUMODE_STEP);
    }

    CpuController_PulseClock(command->Number);    
    SerialTerminal_WriteLine(OK);
    
    return totalRead;
}

//
// CPU Reset
//
// => 'rst' [n]     (n = number of clock cycles to keep the reset active) 0 = latch active
uint16_t CpuReset_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    RingBuffer* const buffer = &serialTerminal->RxBuffer;
    uint16_t totalRead = 0;
    uint8_t temp[10];
    char* endPtr = NULL;
    
    uint16_t number = 4;
    
    if (!RingBuffer_IsEmpty(buffer))
    {
        totalRead += CommandParser_Read(buffer, temp, 9);
        
        command->Number = strtoul((const char*)temp, &endPtr, 10);
        number = command->Number;
    }
    
    CpuController_Reset(1);
    IOController_ReleaseCpuWait();
    
    if (number > 0)
    {
        // give Z80 enough time to reset.
        CpuController_WaitCycles(number);
        CpuController_Reset(0);
        
        SerialTerminal_WriteLine(OK);
    }
    else
    {
        SerialTerminal_WriteLine(SUSPENDED);
    }
    
    return totalRead;
}

//
// Terminal Off
//
// 'to' stop interpretting terminal characters
uint16_t TerminalOff_Execute(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    SerialTerminal_WriteLine(OK);
    serialTerminal->IsActive = 0;
    return 0;
}

//
// Dispatcher entry point
//
uint16_t CommandHandler_DispatchCommand(SerialTerminal* serialTerminal, TerminalCommand* command)
{
    uint16_t bytesRead = 0;
    
    switch(command->Command)
    {
        case COMMAND_MEMORYWRITE:
            bytesRead = DmaParseCommandParameters(&serialTerminal->RxBuffer, command);
            MemoryWrite_Execute(serialTerminal, command);
            break;
        case COMMAND_MEMORYREAD:
            bytesRead = DmaParseCommandParameters(&serialTerminal->RxBuffer, command);
            MemoryRead_Execute(serialTerminal, command);
            break;
        case COMMAND_MEMORYFILL:
            bytesRead = DmaParseCommandParameters(&serialTerminal->RxBuffer, command);
            MemoryFill_Execute(serialTerminal, command);
            break;
        case COMMAND_CLOCKMODE:
            bytesRead = ClockMode_Execute(serialTerminal, command);
            break;
        case COMMAND_CLOCKDIVIDER:
            bytesRead = ClockDivider_Execute(serialTerminal, command);
            break;
        case COMMAND_CLOCKPULSE:
            bytesRead = ClockPulse_Execute(serialTerminal, command);
            break;
        case COMMAND_CPURESET:
            bytesRead = CpuReset_Execute(serialTerminal, command);
            break;
        case COMMAND_TERMINAL_OFF:
            bytesRead = TerminalOff_Execute(serialTerminal, command);
            break;
    }
    
    return bytesRead;
}

/* [] END OF FILE */
