/*******************************************************************************
* File Name: BusDriver_PM.c
* Version 1.30
*
* Description:
*  This file provides Sleep APIs for EMIF Component.
*
* Note:
*   None    
*
********************************************************************************
* Copyright 2011-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "BusDriver.h"

static BusDriver_BACKUP_STRUCT BusDriver_backup;


/*******************************************************************************
* Function Name: BusDriver_SaveConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to save here.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void BusDriver_SaveConfig(void) 
{
    
}


/*******************************************************************************
* Function Name: BusDriver_Sleep
********************************************************************************
*
* Summary:
*  Stops the EMIF operation and saves the user configuration along with 
*  the enable state of the EMIF.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  BusDriver_backup - used to save component state before enter sleep 
*  mode.
*
*******************************************************************************/
void BusDriver_Sleep(void) 
{
    if(BusDriver_ENABLE_REG == BusDriver_ENABLE)       
    {
        BusDriver_backup.enableState = 1u;
    }
    else /* The EMIF block is disabled */
    {
        BusDriver_backup.enableState = 0u;
    }
    
    BusDriver_Stop();
    BusDriver_SaveConfig();
}


/*******************************************************************************
* Function Name: BusDriver_RestoreConfig
********************************************************************************
*
* Summary:
*  All configuration registers are retention. Nothing to restore here. 
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void BusDriver_RestoreConfig(void) 
{
    
}


/*******************************************************************************
* Function Name: BusDriver_Wakeup
********************************************************************************
*
* Summary:
*  Restores the user configuration and restores the enable state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void BusDriver_Wakeup(void) 
{
    BusDriver_RestoreConfig();
    
    if(BusDriver_backup.enableState != 0u)
    {
        /* Enable component's operation */
        BusDriver_Enable();
    } /* Do nothing if component's block was disabled before */
}

/* [] END OF FILE */
