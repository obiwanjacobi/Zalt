/*******************************************************************************
* File Name: ExtBus.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ExtBus_ALIASES_H) /* Pins ExtBus_ALIASES_H */
#define CY_PINS_ExtBus_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define ExtBus_0			(ExtBus__0__PC)
#define ExtBus_0_INTR	((uint16)((uint16)0x0001u << ExtBus__0__SHIFT))

#define ExtBus_1			(ExtBus__1__PC)
#define ExtBus_1_INTR	((uint16)((uint16)0x0001u << ExtBus__1__SHIFT))

#define ExtBus_2			(ExtBus__2__PC)
#define ExtBus_2_INTR	((uint16)((uint16)0x0001u << ExtBus__2__SHIFT))

#define ExtBus_3			(ExtBus__3__PC)
#define ExtBus_3_INTR	((uint16)((uint16)0x0001u << ExtBus__3__SHIFT))

#define ExtBus_4			(ExtBus__4__PC)
#define ExtBus_4_INTR	((uint16)((uint16)0x0001u << ExtBus__4__SHIFT))

#define ExtBus_5			(ExtBus__5__PC)
#define ExtBus_5_INTR	((uint16)((uint16)0x0001u << ExtBus__5__SHIFT))

#define ExtBus_6			(ExtBus__6__PC)
#define ExtBus_6_INTR	((uint16)((uint16)0x0001u << ExtBus__6__SHIFT))

#define ExtBus_7			(ExtBus__7__PC)
#define ExtBus_7_INTR	((uint16)((uint16)0x0001u << ExtBus__7__SHIFT))

#define ExtBus_8			(ExtBus__8__PC)
#define ExtBus_8_INTR	((uint16)((uint16)0x0001u << ExtBus__8__SHIFT))

#define ExtBus_9			(ExtBus__9__PC)
#define ExtBus_9_INTR	((uint16)((uint16)0x0001u << ExtBus__9__SHIFT))

#define ExtBus_10			(ExtBus__10__PC)
#define ExtBus_10_INTR	((uint16)((uint16)0x0001u << ExtBus__10__SHIFT))

#define ExtBus_INTR_ALL	 ((uint16)(ExtBus_0_INTR| ExtBus_1_INTR| ExtBus_2_INTR| ExtBus_3_INTR| ExtBus_4_INTR| ExtBus_5_INTR| ExtBus_6_INTR| ExtBus_7_INTR| ExtBus_8_INTR| ExtBus_9_INTR| ExtBus_10_INTR))
#define ExtBus_MemReq			(ExtBus__MemReq__PC)
#define ExtBus_MemReq_INTR	((uint16)((uint16)0x0001u << ExtBus__0__SHIFT))

#define ExtBus_IoReq			(ExtBus__IoReq__PC)
#define ExtBus_IoReq_INTR	((uint16)((uint16)0x0001u << ExtBus__1__SHIFT))

#define ExtBus_Rd			(ExtBus__Rd__PC)
#define ExtBus_Rd_INTR	((uint16)((uint16)0x0001u << ExtBus__2__SHIFT))

#define ExtBus_Wr			(ExtBus__Wr__PC)
#define ExtBus_Wr_INTR	((uint16)((uint16)0x0001u << ExtBus__3__SHIFT))

#define ExtBus_BusReq			(ExtBus__BusReq__PC)
#define ExtBus_BusReq_INTR	((uint16)((uint16)0x0001u << ExtBus__4__SHIFT))

#define ExtBus_BusAck			(ExtBus__BusAck__PC)
#define ExtBus_BusAck_INTR	((uint16)((uint16)0x0001u << ExtBus__5__SHIFT))

#define ExtBus_CpuHalt			(ExtBus__CpuHalt__PC)
#define ExtBus_CpuHalt_INTR	((uint16)((uint16)0x0001u << ExtBus__6__SHIFT))

#define ExtBus_CpuRst			(ExtBus__CpuRst__PC)
#define ExtBus_CpuRst_INTR	((uint16)((uint16)0x0001u << ExtBus__7__SHIFT))

#define ExtBus_CpuClk			(ExtBus__CpuClk__PC)
#define ExtBus_CpuClk_INTR	((uint16)((uint16)0x0001u << ExtBus__8__SHIFT))

#define ExtBus_CpuWait			(ExtBus__CpuWait__PC)
#define ExtBus_CpuWait_INTR	((uint16)((uint16)0x0001u << ExtBus__9__SHIFT))

#define ExtBus_CpuM1			(ExtBus__CpuM1__PC)
#define ExtBus_CpuM1_INTR	((uint16)((uint16)0x0001u << ExtBus__10__SHIFT))

#endif /* End Pins ExtBus_ALIASES_H */


/* [] END OF FILE */
