/*******************************************************************************
* File Name: LsbA.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LsbA_ALIASES_H) /* Pins LsbA_ALIASES_H */
#define CY_PINS_LsbA_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define LsbA_0			(LsbA__0__PC)
#define LsbA_0_INTR	((uint16)((uint16)0x0001u << LsbA__0__SHIFT))

#define LsbA_1			(LsbA__1__PC)
#define LsbA_1_INTR	((uint16)((uint16)0x0001u << LsbA__1__SHIFT))

#define LsbA_2			(LsbA__2__PC)
#define LsbA_2_INTR	((uint16)((uint16)0x0001u << LsbA__2__SHIFT))

#define LsbA_3			(LsbA__3__PC)
#define LsbA_3_INTR	((uint16)((uint16)0x0001u << LsbA__3__SHIFT))

#define LsbA_4			(LsbA__4__PC)
#define LsbA_4_INTR	((uint16)((uint16)0x0001u << LsbA__4__SHIFT))

#define LsbA_5			(LsbA__5__PC)
#define LsbA_5_INTR	((uint16)((uint16)0x0001u << LsbA__5__SHIFT))

#define LsbA_6			(LsbA__6__PC)
#define LsbA_6_INTR	((uint16)((uint16)0x0001u << LsbA__6__SHIFT))

#define LsbA_7			(LsbA__7__PC)
#define LsbA_7_INTR	((uint16)((uint16)0x0001u << LsbA__7__SHIFT))

#define LsbA_INTR_ALL	 ((uint16)(LsbA_0_INTR| LsbA_1_INTR| LsbA_2_INTR| LsbA_3_INTR| LsbA_4_INTR| LsbA_5_INTR| LsbA_6_INTR| LsbA_7_INTR))

#endif /* End Pins LsbA_ALIASES_H */


/* [] END OF FILE */
