#ifndef __IOCONTROLLER_H__
#define __IOCONTROLLER_H__
    
#include <project.h>

// Mode flags
#define MODE_NONE    0
#define MODE_READ    1
#define MODE_WRITE   2
#define MODE_MEMORY  4
#define MODE_IO      8
    
typedef struct
{
    uint8_t Mode;   // MODE_X flags
    uint8_t Address;
    uint8_t Data;
    
} IOInfo;
    
//
// IO Addresses for SystemController peripherals
//

// test loop IO address
#define IO_TEST_LOOP    0x00

// fixed serial commlink to PC
#define IO_Serial       0x20

void IOController_Init();

// for system use, don't call
inline void IOController_ISR_OnIOInterrupt();
inline void IOController_Output(IOInfo* ioInfo);
inline void IOController_Input(IOInfo* ioInfo);
    
void IOController_ReleaseCpuWait();

#endif  //__IOCONTROLLER_H__

/* [] END OF FILE */
