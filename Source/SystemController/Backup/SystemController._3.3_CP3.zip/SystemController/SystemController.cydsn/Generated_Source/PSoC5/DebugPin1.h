/*******************************************************************************
* File Name: DebugPin1.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_DebugPin1_H) /* Pins DebugPin1_H */
#define CY_PINS_DebugPin1_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "DebugPin1_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 DebugPin1__PORT == 15 && ((DebugPin1__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    DebugPin1_Write(uint8 value);
void    DebugPin1_SetDriveMode(uint8 mode);
uint8   DebugPin1_ReadDataReg(void);
uint8   DebugPin1_Read(void);
void    DebugPin1_SetInterruptMode(uint16 position, uint16 mode);
uint8   DebugPin1_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the DebugPin1_SetDriveMode() function.
     *  @{
     */
        #define DebugPin1_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define DebugPin1_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define DebugPin1_DM_RES_UP          PIN_DM_RES_UP
        #define DebugPin1_DM_RES_DWN         PIN_DM_RES_DWN
        #define DebugPin1_DM_OD_LO           PIN_DM_OD_LO
        #define DebugPin1_DM_OD_HI           PIN_DM_OD_HI
        #define DebugPin1_DM_STRONG          PIN_DM_STRONG
        #define DebugPin1_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define DebugPin1_MASK               DebugPin1__MASK
#define DebugPin1_SHIFT              DebugPin1__SHIFT
#define DebugPin1_WIDTH              1u

/* Interrupt constants */
#if defined(DebugPin1__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in DebugPin1_SetInterruptMode() function.
     *  @{
     */
        #define DebugPin1_INTR_NONE      (uint16)(0x0000u)
        #define DebugPin1_INTR_RISING    (uint16)(0x0001u)
        #define DebugPin1_INTR_FALLING   (uint16)(0x0002u)
        #define DebugPin1_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define DebugPin1_INTR_MASK      (0x01u) 
#endif /* (DebugPin1__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define DebugPin1_PS                     (* (reg8 *) DebugPin1__PS)
/* Data Register */
#define DebugPin1_DR                     (* (reg8 *) DebugPin1__DR)
/* Port Number */
#define DebugPin1_PRT_NUM                (* (reg8 *) DebugPin1__PRT) 
/* Connect to Analog Globals */                                                  
#define DebugPin1_AG                     (* (reg8 *) DebugPin1__AG)                       
/* Analog MUX bux enable */
#define DebugPin1_AMUX                   (* (reg8 *) DebugPin1__AMUX) 
/* Bidirectional Enable */                                                        
#define DebugPin1_BIE                    (* (reg8 *) DebugPin1__BIE)
/* Bit-mask for Aliased Register Access */
#define DebugPin1_BIT_MASK               (* (reg8 *) DebugPin1__BIT_MASK)
/* Bypass Enable */
#define DebugPin1_BYP                    (* (reg8 *) DebugPin1__BYP)
/* Port wide control signals */                                                   
#define DebugPin1_CTL                    (* (reg8 *) DebugPin1__CTL)
/* Drive Modes */
#define DebugPin1_DM0                    (* (reg8 *) DebugPin1__DM0) 
#define DebugPin1_DM1                    (* (reg8 *) DebugPin1__DM1)
#define DebugPin1_DM2                    (* (reg8 *) DebugPin1__DM2) 
/* Input Buffer Disable Override */
#define DebugPin1_INP_DIS                (* (reg8 *) DebugPin1__INP_DIS)
/* LCD Common or Segment Drive */
#define DebugPin1_LCD_COM_SEG            (* (reg8 *) DebugPin1__LCD_COM_SEG)
/* Enable Segment LCD */
#define DebugPin1_LCD_EN                 (* (reg8 *) DebugPin1__LCD_EN)
/* Slew Rate Control */
#define DebugPin1_SLW                    (* (reg8 *) DebugPin1__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define DebugPin1_PRTDSI__CAPS_SEL       (* (reg8 *) DebugPin1__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define DebugPin1_PRTDSI__DBL_SYNC_IN    (* (reg8 *) DebugPin1__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define DebugPin1_PRTDSI__OE_SEL0        (* (reg8 *) DebugPin1__PRTDSI__OE_SEL0) 
#define DebugPin1_PRTDSI__OE_SEL1        (* (reg8 *) DebugPin1__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define DebugPin1_PRTDSI__OUT_SEL0       (* (reg8 *) DebugPin1__PRTDSI__OUT_SEL0) 
#define DebugPin1_PRTDSI__OUT_SEL1       (* (reg8 *) DebugPin1__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define DebugPin1_PRTDSI__SYNC_OUT       (* (reg8 *) DebugPin1__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(DebugPin1__SIO_CFG)
    #define DebugPin1_SIO_HYST_EN        (* (reg8 *) DebugPin1__SIO_HYST_EN)
    #define DebugPin1_SIO_REG_HIFREQ     (* (reg8 *) DebugPin1__SIO_REG_HIFREQ)
    #define DebugPin1_SIO_CFG            (* (reg8 *) DebugPin1__SIO_CFG)
    #define DebugPin1_SIO_DIFF           (* (reg8 *) DebugPin1__SIO_DIFF)
#endif /* (DebugPin1__SIO_CFG) */

/* Interrupt Registers */
#if defined(DebugPin1__INTSTAT)
    #define DebugPin1_INTSTAT            (* (reg8 *) DebugPin1__INTSTAT)
    #define DebugPin1_SNAP               (* (reg8 *) DebugPin1__SNAP)
    
	#define DebugPin1_0_INTTYPE_REG 		(* (reg8 *) DebugPin1__0__INTTYPE)
#endif /* (DebugPin1__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_DebugPin1_H */


/* [] END OF FILE */
