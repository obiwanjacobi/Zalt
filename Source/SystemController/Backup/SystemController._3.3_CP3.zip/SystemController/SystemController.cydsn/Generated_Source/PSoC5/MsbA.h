/*******************************************************************************
* File Name: MsbA.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_MsbA_H) /* Pins MsbA_H */
#define CY_PINS_MsbA_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "MsbA_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 MsbA__PORT == 15 && ((MsbA__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    MsbA_Write(uint8 value);
void    MsbA_SetDriveMode(uint8 mode);
uint8   MsbA_ReadDataReg(void);
uint8   MsbA_Read(void);
void    MsbA_SetInterruptMode(uint16 position, uint16 mode);
uint8   MsbA_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the MsbA_SetDriveMode() function.
     *  @{
     */
        #define MsbA_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define MsbA_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define MsbA_DM_RES_UP          PIN_DM_RES_UP
        #define MsbA_DM_RES_DWN         PIN_DM_RES_DWN
        #define MsbA_DM_OD_LO           PIN_DM_OD_LO
        #define MsbA_DM_OD_HI           PIN_DM_OD_HI
        #define MsbA_DM_STRONG          PIN_DM_STRONG
        #define MsbA_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define MsbA_MASK               MsbA__MASK
#define MsbA_SHIFT              MsbA__SHIFT
#define MsbA_WIDTH              8u

/* Interrupt constants */
#if defined(MsbA__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in MsbA_SetInterruptMode() function.
     *  @{
     */
        #define MsbA_INTR_NONE      (uint16)(0x0000u)
        #define MsbA_INTR_RISING    (uint16)(0x0001u)
        #define MsbA_INTR_FALLING   (uint16)(0x0002u)
        #define MsbA_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define MsbA_INTR_MASK      (0x01u) 
#endif /* (MsbA__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define MsbA_PS                     (* (reg8 *) MsbA__PS)
/* Data Register */
#define MsbA_DR                     (* (reg8 *) MsbA__DR)
/* Port Number */
#define MsbA_PRT_NUM                (* (reg8 *) MsbA__PRT) 
/* Connect to Analog Globals */                                                  
#define MsbA_AG                     (* (reg8 *) MsbA__AG)                       
/* Analog MUX bux enable */
#define MsbA_AMUX                   (* (reg8 *) MsbA__AMUX) 
/* Bidirectional Enable */                                                        
#define MsbA_BIE                    (* (reg8 *) MsbA__BIE)
/* Bit-mask for Aliased Register Access */
#define MsbA_BIT_MASK               (* (reg8 *) MsbA__BIT_MASK)
/* Bypass Enable */
#define MsbA_BYP                    (* (reg8 *) MsbA__BYP)
/* Port wide control signals */                                                   
#define MsbA_CTL                    (* (reg8 *) MsbA__CTL)
/* Drive Modes */
#define MsbA_DM0                    (* (reg8 *) MsbA__DM0) 
#define MsbA_DM1                    (* (reg8 *) MsbA__DM1)
#define MsbA_DM2                    (* (reg8 *) MsbA__DM2) 
/* Input Buffer Disable Override */
#define MsbA_INP_DIS                (* (reg8 *) MsbA__INP_DIS)
/* LCD Common or Segment Drive */
#define MsbA_LCD_COM_SEG            (* (reg8 *) MsbA__LCD_COM_SEG)
/* Enable Segment LCD */
#define MsbA_LCD_EN                 (* (reg8 *) MsbA__LCD_EN)
/* Slew Rate Control */
#define MsbA_SLW                    (* (reg8 *) MsbA__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define MsbA_PRTDSI__CAPS_SEL       (* (reg8 *) MsbA__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define MsbA_PRTDSI__DBL_SYNC_IN    (* (reg8 *) MsbA__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define MsbA_PRTDSI__OE_SEL0        (* (reg8 *) MsbA__PRTDSI__OE_SEL0) 
#define MsbA_PRTDSI__OE_SEL1        (* (reg8 *) MsbA__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define MsbA_PRTDSI__OUT_SEL0       (* (reg8 *) MsbA__PRTDSI__OUT_SEL0) 
#define MsbA_PRTDSI__OUT_SEL1       (* (reg8 *) MsbA__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define MsbA_PRTDSI__SYNC_OUT       (* (reg8 *) MsbA__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(MsbA__SIO_CFG)
    #define MsbA_SIO_HYST_EN        (* (reg8 *) MsbA__SIO_HYST_EN)
    #define MsbA_SIO_REG_HIFREQ     (* (reg8 *) MsbA__SIO_REG_HIFREQ)
    #define MsbA_SIO_CFG            (* (reg8 *) MsbA__SIO_CFG)
    #define MsbA_SIO_DIFF           (* (reg8 *) MsbA__SIO_DIFF)
#endif /* (MsbA__SIO_CFG) */

/* Interrupt Registers */
#if defined(MsbA__INTSTAT)
    #define MsbA_INTSTAT            (* (reg8 *) MsbA__INTSTAT)
    #define MsbA_SNAP               (* (reg8 *) MsbA__SNAP)
    
	#define MsbA_0_INTTYPE_REG 		(* (reg8 *) MsbA__0__INTTYPE)
	#define MsbA_1_INTTYPE_REG 		(* (reg8 *) MsbA__1__INTTYPE)
	#define MsbA_2_INTTYPE_REG 		(* (reg8 *) MsbA__2__INTTYPE)
	#define MsbA_3_INTTYPE_REG 		(* (reg8 *) MsbA__3__INTTYPE)
	#define MsbA_4_INTTYPE_REG 		(* (reg8 *) MsbA__4__INTTYPE)
	#define MsbA_5_INTTYPE_REG 		(* (reg8 *) MsbA__5__INTTYPE)
	#define MsbA_6_INTTYPE_REG 		(* (reg8 *) MsbA__6__INTTYPE)
	#define MsbA_7_INTTYPE_REG 		(* (reg8 *) MsbA__7__INTTYPE)
#endif /* (MsbA__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_MsbA_H */


/* [] END OF FILE */
