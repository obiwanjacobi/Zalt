/*******************************************************************************
* File Name: Z80Ctrl_WaitCtrlReg_PM.c
* Version 1.80
*
* Description:
*  This file contains the setup, control, and status commands to support 
*  the component operation in the low power mode. 
*
* Note:
*
********************************************************************************
* Copyright 2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Z80Ctrl_WaitCtrlReg.h"

/* Check for removal by optimization */
#if !defined(Z80Ctrl_WaitCtrlReg_Sync_ctrl_reg__REMOVED)

static Z80Ctrl_WaitCtrlReg_BACKUP_STRUCT  Z80Ctrl_WaitCtrlReg_backup = {0u};

    
/*******************************************************************************
* Function Name: Z80Ctrl_WaitCtrlReg_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Z80Ctrl_WaitCtrlReg_SaveConfig(void) 
{
    Z80Ctrl_WaitCtrlReg_backup.controlState = Z80Ctrl_WaitCtrlReg_Control;
}


/*******************************************************************************
* Function Name: Z80Ctrl_WaitCtrlReg_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the control register value.
*
* Parameters:
*  None
*
* Return:
*  None
*
*
*******************************************************************************/
void Z80Ctrl_WaitCtrlReg_RestoreConfig(void) 
{
     Z80Ctrl_WaitCtrlReg_Control = Z80Ctrl_WaitCtrlReg_backup.controlState;
}


/*******************************************************************************
* Function Name: Z80Ctrl_WaitCtrlReg_Sleep
********************************************************************************
*
* Summary:
*  Prepares the component for entering the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Z80Ctrl_WaitCtrlReg_Sleep(void) 
{
    Z80Ctrl_WaitCtrlReg_SaveConfig();
}


/*******************************************************************************
* Function Name: Z80Ctrl_WaitCtrlReg_Wakeup
********************************************************************************
*
* Summary:
*  Restores the component after waking up from the low power mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void Z80Ctrl_WaitCtrlReg_Wakeup(void)  
{
    Z80Ctrl_WaitCtrlReg_RestoreConfig();
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
