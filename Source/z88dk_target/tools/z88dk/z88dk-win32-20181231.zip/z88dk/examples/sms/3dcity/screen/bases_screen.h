#ifndef _BASES_SCREEN_H_
#define _BASES_SCREEN_H_

void screen_bases_screen_init();

#endif//_BASES_SCREEN_H_
