#define PREFIX "/usr/local/share/z88dk"
#define UNIX 1
#define EXEC_PREFIX ""
#define Z88DK_VERSION "13634-8f8e7e5-20181231"
