
// Version Information

#include "../config.h"

char *version = "v" Z88DK_VERSION;

// Internal Representation of Memory Map

int main(int argc, char **argv)
{
    return 0;
}
